/* ============================================================
   VIEW · CANDIDATE DETAIL + ACH ADJUDICATION BOARD
   step-through the disconfirming tests; promote / kill
   ============================================================ */
const { useState: useStateC, useEffect: useEffectC, useMemo: useMemoC, useRef: useRefC } = React;
const CC = () => window.CHORUS;

const HYP_LABEL = {
  warm_debris_disk:'Warm debris disk', agn_blend:'Background AGN blend',
  young_stellar:'Young stellar / protoplanetary', data_artifact:'Data artifact / confusion',
  techno_ir_excess:'Techno · residual IR excess', rfi_terrestrial:'Terrestrial RFI',
  stellar_pulsation:'Stellar pulsation', astrometric_binary:'Unseen companion (astrometric)',
  techno_multichannel:'Techno · multi-channel residual',
};
const isTechno = (k)=> k.startsWith('techno');

function PosteriorBar({ prior, value, disconfirmed, techno }) {
  const col = disconfirmed ? 'var(--red)' : techno ? 'var(--signal)' : 'var(--ink-faint)';
  return (
    <div style={{ position:'relative', height:18, background:'var(--void)', border:'1px solid var(--line-soft)', borderRadius:2 }}>
      <div style={{ position:'absolute', inset:0, width:`${Math.max(2,value*100)}%`,
        background:`color-mix(in oklch, ${col}, transparent 68%)`, borderRight:`2px solid ${col}`,
        transition:'width .5s cubic-bezier(.3,.7,.3,1)', borderRadius:'1px' }} />
      {/* prior tick */}
      <div title={`prior ${prior.toFixed(2)}`} style={{ position:'absolute', top:-2, bottom:-2, left:`${prior*100}%`, width:1, background:'var(--ink-ghost)' }} />
      <span className="tnum" style={{ position:'absolute', right:5, top:1, fontSize:10, color:col }}>{value.toFixed(2)}</span>
    </div>
  );
}

function EvidenceLine({ ev }) {
  const map = { disconfirm:{c:'var(--red)',t:'DISCONFIRMS'}, support:{c:'var(--signal)',t:'SUPPORTS'}, neutral:{c:'var(--ink-faint)',t:'NEUTRAL'} };
  const m = map[ev.effect];
  return (
    <div className="reveal" style={{ display:'flex', gap:9, padding:'7px 0', borderTop:'1px dashed var(--line-soft)' }}>
      <span style={{ width:3, alignSelf:'stretch', background:m.c, borderRadius:2, flex:'none' }} />
      <div style={{ minWidth:0, flex:1 }}>
        <div style={{ fontSize:10, color:'var(--ink-faint)', letterSpacing:'0.04em' }}>↳ TEST · {ev.test}</div>
        <div className="sans" style={{ fontSize:11.5, color:'var(--ink-dim)', marginTop:2, lineHeight:1.45, textWrap:'pretty' }}>{ev.result}</div>
      </div>
      <span style={{ fontSize:8.5, letterSpacing:'0.1em', color:m.c, flex:'none', paddingTop:2 }}>{m.t}</span>
    </div>
  );
}

function AchBoard({ cand, onResolve }) {
  const hyps = cand.ach.hypotheses;
  // flat evidence steps in hypothesis order
  const steps = useMemoC(()=>{
    const s = []; hyps.forEach((h,hi)=> h.evidence.forEach((e,ei)=> s.push({ hi, ei })));
    return s;
  }, [cand.id]);
  const totalEv = steps.length;

  const [revealed, setRevealed] = useStateC(0);
  const [running, setRunning] = useStateC(false);
  const timer = useRefC(null);

  useEffectC(()=>{ setRevealed(0); setRunning(false); if(timer.current) clearInterval(timer.current); }, [cand.id]);

  // how many evidence of a given hyp are revealed
  const revOfHyp = (hi)=> steps.slice(0,revealed).filter(s=>s.hi===hi).length;

  const dispPosterior = (h, hi)=>{
    const tot = h.evidence.length;
    if (tot===0) return h.posterior; // nothing to reveal
    const r = revOfHyp(hi);
    return h.prior + (h.posterior - h.prior) * (r/tot);
  };
  const dispDisconf = (h, hi)=> h.disconfirmed && h.evidence.length>0 && revOfHyp(hi)===h.evidence.length;

  const complete = revealed>=totalEv;

  useEffectC(()=>{
    if (!running) return;
    timer.current = setInterval(()=>{
      setRevealed(r=>{ if (r>=totalEv){ clearInterval(timer.current); setRunning(false); return r; } return r+1; });
    }, 720);
    return ()=> clearInterval(timer.current);
  }, [running, totalEv]);

  const verdict = complete ? (cand.ach.promote===true?'promote':cand.ach.promote===false?'kill':'inconclusive') : 'running';

  return (
    <Panel>
      <Strip label="ACH · ANALYSIS OF COMPETING HYPOTHESES" accent="var(--ch-radio)" right={
        <span className="eyebrow">{revealed}/{totalEv} TESTS</span>
      } />
      {/* control bar */}
      <div style={{ display:'flex', alignItems:'center', gap:8, padding:'10px 13px', borderBottom:'1px solid var(--line-soft)' }}>
        <button className="btn" disabled={complete||running} onClick={()=>setRevealed(r=>Math.min(totalEv,r+1))}>▸ Step test</button>
        <button className={`btn ${running?'':'btn--primary'}`} disabled={complete} onClick={()=>setRunning(r=>!r)}>
          {running?'❚❚ Pause':'▶ Run all tests'}
        </button>
        <button className="btn btn--ghost" onClick={()=>{ setRevealed(0); setRunning(false); }}>↺ Reset</button>
        <div style={{ flex:1 }} />
        <span className="sans" style={{ fontSize:10.5, color:'var(--ink-ghost)', maxWidth:230, textAlign:'right', lineHeight:1.3 }}>
          Adjudicator (Sonnet) frames evidence · numbers returned by deterministic tools
        </span>
      </div>

      {/* hypotheses */}
      <div style={{ padding:'4px 13px 13px' }}>
        {hyps.map((h, hi)=>{
          const techno = isTechno(h.kind);
          const disc = dispDisconf(h, hi);
          const post = dispPosterior(h, hi);
          const revEv = revOfHyp(hi);
          return (
            <div key={h.kind} style={{ padding:'11px 0', borderBottom: hi<hyps.length-1?'1px solid var(--line-soft)':'none' }}>
              <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:7 }}>
                <span style={{ fontSize:12.5, flex:'none', width:200,
                  color: disc?'var(--red)':techno?'var(--signal)':'var(--ink)',
                  textDecoration: disc?'line-through':'none', textDecorationColor:'var(--red-dim)' }}>
                  {techno && '◆ '}{HYP_LABEL[h.kind]||h.kind}
                </span>
                <div style={{ flex:1 }}><PosteriorBar prior={h.prior} value={post} disconfirmed={disc} techno={techno} /></div>
                {disc && <span className="chip is-killed" style={{ fontSize:8.5, padding:'1px 6px' }}>DISCONFIRMED</span>}
                {techno && complete && verdict==='promote' && <span className="chip is-promoted" style={{ fontSize:8.5, padding:'1px 6px' }}>SURVIVES</span>}
              </div>
              {/* revealed evidence */}
              <div style={{ paddingLeft:4 }}>
                {h.evidence.slice(0, revEv).map((ev,ei)=><EvidenceLine key={ei} ev={ev} />)}
                {h.evidence.length>0 && revEv===0 && <div style={{ fontSize:10, color:'var(--ink-ghost)', padding:'4px 0' }}>— {h.evidence.length} disconfirming test{h.evidence.length>1?'s':''} queued</div>}
                {h.evidence.length===0 && <div style={{ fontSize:10, color:'var(--ink-ghost)', padding:'4px 0' }}>— no tests defined yet for this channel set</div>}
              </div>
            </div>
          );
        })}
      </div>

      {/* verdict footer */}
      <VerdictBar verdict={verdict} cand={cand} onResolve={onResolve} />
    </Panel>
  );
}

function VerdictBar({ verdict, cand, onResolve }) {
  const [acted, setActed] = useStateC(null);
  useEffectC(()=>setActed(null), [cand.id]);

  if (verdict==='running') {
    return <div style={{ padding:'12px 14px', borderTop:'1px solid var(--line)', color:'var(--ink-ghost)', fontSize:11.5 }}>
      <span className="caret">Run the disconfirming tests to reach a verdict</span></div>;
  }

  let bg, col, title, body, actions;
  if (verdict==='promote') {
    bg='color-mix(in oklch, var(--signal), var(--void) 90%)'; col='var(--signal)';
    title='ALL NATURAL HYPOTHESES DISCONFIRMED · TECHNO SURVIVES';
    body='Promotion criterion met. Not a positive detection — a residual unexplained signature. Generate a Coherence Anomaly Report.';
    actions = acted==='promote'
      ? <span className="chip is-promoted">✓ {cand.car?cand.car.ref:'CAR-NEW'} GENERATED</span>
      : <button className="btn btn--primary" onClick={()=>{ setActed('promote'); onResolve&&onResolve('promote'); }}>◆ Promote → generate CAR</button>;
  } else if (verdict==='kill') {
    bg='color-mix(in oklch, var(--red), var(--void) 90%)'; col='var(--red)';
    title='TECHNO HYPOTHESIS DISCONFIRMED · CANDIDATE KILLED';
    body = cand.note || 'A natural hypothesis explains the signal. The candidate is removed from the CAR queue.';
    actions = acted==='kill'
      ? <span className="chip is-killed">✓ MARKED KILLED</span>
      : <button className="btn btn--danger" onClick={()=>{ setActed('kill'); onResolve&&onResolve('kill'); }}>✕ Confirm kill</button>;
  } else {
    bg='color-mix(in oklch, var(--amber), var(--void) 91%)'; col='var(--amber)';
    title='ADJUDICATION INCONCLUSIVE';
    body='Surviving natural hypotheses remain, or required channels are deferred. Candidate stays in vetting until more tests resolve.';
    actions = <span className="chip is-vetting">HELD · VETTING</span>;
  }

  return (
    <div style={{ padding:'14px', borderTop:`1px solid ${col}`, background:bg, display:'flex', gap:14, alignItems:'center' }}>
      <div style={{ flex:1 }}>
        <div style={{ fontSize:11, letterSpacing:'0.1em', color:col, marginBottom:4 }}>{title}</div>
        <p className="sans" style={{ fontSize:11.5, color:'var(--ink-dim)', lineHeight:1.5, textWrap:'pretty' }}>{body}</p>
      </div>
      <div style={{ flex:'none' }}>{actions}</div>
    </div>
  );
}

function DetectionList({ cand }) {
  const surveyMeta = {
    gaia_dr3:{ name:'Gaia DR3', ch:'astrometric', role:'parallax · PM · G/BP/RP', host:'gea.esac.esa.int/tap' },
    '2mass':{ name:'2MASS PSC', ch:null, role:'J/H/Ks (SED input)', host:'irsa.ipac · fp_psc' },
    allwise:{ name:'AllWISE', ch:'ir_excess', role:'W1–W4 · cc_flags · ext_flg', host:'irsa.ipac · allwise_p3as_psd' },
    tess:{ name:'TESS', ch:'transit_shape', role:'SAP/PDCSAP light curve', host:'MAST' },
    bldr:{ name:'BL Open Data', ch:'radio_drift', role:'filterbank · ON/OFF cadence', host:'bl-opendata' },
  };
  return (
    <Panel>
      <Strip label="SUPPORTED_BY · detections" right={<span className="eyebrow">{cand.surveys.length} SURVEYS</span>} />
      {cand.surveys.map(s=>{
        const m = surveyMeta[s];
        return (
          <div key={s} style={{ display:'flex', gap:10, padding:'10px 13px', borderBottom:'1px solid var(--line-soft)', alignItems:'center' }}>
            {m.ch ? <ChannelGlyph ch={m.ch} size={26} /> : <span style={{ width:26, height:26, display:'flex', alignItems:'center', justifyContent:'center', border:'1px dashed var(--line)', borderRadius:2, fontSize:8, color:'var(--ink-ghost)' }}>IN</span>}
            <div style={{ flex:1, minWidth:0 }}>
              <div style={{ fontSize:11.5, color:'var(--ink)' }}>{m.name}</div>
              <div style={{ fontSize:9.5, color:'var(--ink-ghost)', marginTop:2 }}>{m.role}</div>
            </div>
            <div style={{ textAlign:'right' }}>
              {m.ch && <div style={{ fontSize:9.5, color:`var(${CC().CHANNELS[m.ch].varName})` }}>{CC().CHANNELS[m.ch].label}</div>}
              <div style={{ fontSize:9, color:'var(--ink-ghost)', marginTop:2 }}>{m.host}</div>
            </div>
          </div>
        );
      })}
    </Panel>
  );
}

function CandidateView({ id, go }) {
  const cand = CC().candidateById(id);
  const [localStatus, setLocalStatus] = useStateC(cand?cand.status:'open');
  useEffectC(()=>{ if(cand) setLocalStatus(cand.status); }, [id]);
  if (!cand) return <div style={{ padding:30, color:'var(--ink-faint)' }}>candidate <code>{id}</code> not found · <span className="lnk" onClick={()=>go('queue')}>back to queue</span></div>;

  const excessBands = cand.sed.filter(b=>b.excess>0.04);

  return (
    <div className="scroll" style={{ height:'100%' }}>
      {/* header */}
      <div className="scan" style={{ display:'flex', alignItems:'center', gap:14, padding:'13px 18px', borderBottom:'1px solid var(--line)',
        position:'sticky', top:0, background:'var(--void-2)', zIndex:5 }}>
        <button className="btn btn--ghost" onClick={()=>go('queue')}>← queue</button>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ display:'flex', alignItems:'center', gap:10 }}>
            <span style={{ fontSize:16, color:'var(--ink)' }}>{cand.id}</span>
            {cand.hepRef && <span className="chip" style={{ color:'var(--ink-faint)' }}>HEPHAISTOS · {cand.hepRef}</span>}
            <StatusBadge status={localStatus} pulse />
          </div>
          <div className="tnum" style={{ fontSize:11, color:'var(--ink-faint)', marginTop:3 }}>{cand.gaiaId} · {fmtCoord(cand.ra,cand.dec)} · {cand.constellation}</div>
        </div>
        {cand.car && <button className="btn" onClick={()=>go('car', cand.id)}>view {cand.car.ref} →</button>}
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'minmax(300px, 0.85fr) minmax(440px, 1.3fr)', gap:16, padding:18, alignItems:'start' }}>
        {/* LEFT — sky + props + detections + SED */}
        <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
          <Panel>
            <Strip label="MULTI-CHANNEL AGREEMENT" accent="var(--signal)" right={<span className="eyebrow">{cand.nChannels} OF 4</span>} />
            <div style={{ display:'flex', gap:14, padding:'16px', alignItems:'center' }}>
              <ConvergenceTarget channels={cand.channels} status={localStatus} size={132} />
              <div style={{ flex:1, display:'flex', flexDirection:'column', gap:9 }}>
                {['ir_excess','transit_shape','radio_drift','astrometric'].map(ch=>{
                  const on = cand.channels.includes(ch); const meta = CC().CHANNELS[ch];
                  return (
                    <div key={ch} style={{ display:'flex', alignItems:'center', gap:8, opacity:on?1:0.35 }}>
                      <span className="dot" style={{ background: on?`var(${meta.varName})`:'var(--line-bright)' }} />
                      <span style={{ fontSize:10.5, color: on?'var(--ink)':'var(--ink-ghost)', flex:1 }}>{meta.label}</span>
                      <span style={{ fontSize:9, color:'var(--ink-ghost)' }}>{on?'FIRED':'—'}</span>
                    </div>
                  );
                })}
                <div className="hr" style={{ margin:'2px 0' }} />
                <div style={{ display:'flex', justifyContent:'space-between' }}>
                  <span className="eyebrow">JOINT FAP</span>
                  <span className="tnum" style={{ fontSize:12, color: cand.nChannels>=3?'var(--signal)':'var(--ink-dim)' }}>{CC().fmtFAP(cand.jointFAP)}</span>
                </div>
                <div style={{ fontSize:9, color:'var(--ink-ghost)' }}>look-elsewhere corrected · §10.3</div>
              </div>
            </div>
          </Panel>

          <Panel>
            <Strip label="OBJECT · J2016.0" />
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'13px 16px', padding:'14px 15px' }}>
              <Stat label="DISTANCE" value={cand.distance_pc} unit="pc" />
              <Stat label="Teff" value={cand.teff} unit="K" />
              <Stat label="BP − RP" value={cand.bp_rp.toFixed(2)} />
              <Stat label="G MAG" value={cand.gmag.toFixed(2)} />
              <Stat label="PROPER MOTION" value={cand.pm||'—'} unit={cand.pm?'mas/yr':''} />
              <Stat label="ANOM SCORE" value={cand.anomScore.toFixed(1)} unit="σ" color="var(--ch-ir)" />
            </div>
          </Panel>

          <DetectionList cand={cand} />
        </div>

        {/* RIGHT — SED + ACH board */}
        <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
          <Panel>
            <Strip label="SED · photosphere fit + MIR excess" accent="var(--ch-ir)" right={
              <span className="chip" style={{ color:'var(--ch-ir)', borderColor:'color-mix(in oklch, var(--ch-ir), transparent 60%)' }}>
                IR EXCESS · {excessBands.map(b=>b.name).join('+')}
              </span>
            } />
            <div style={{ padding:'14px 12px 8px' }}>
              <SEDPlot sed={cand.sed} />
            </div>
            <div style={{ display:'flex', gap:18, padding:'4px 16px 14px', flexWrap:'wrap', borderTop:'1px solid var(--line-soft)' }}>
              <span style={{ fontSize:10, color:'var(--ink-faint)', display:'flex', alignItems:'center', gap:6 }}>
                <svg width="22" height="2"><line x1="0" y1="1" x2="22" y2="1" stroke="var(--ink-faint)" strokeWidth="1.4" strokeDasharray="5 3"/></svg>
                BT-Settl photosphere (fit to Gaia+2MASS+W1+W2)</span>
              <span style={{ fontSize:10, color:'var(--ink-faint)', display:'flex', alignItems:'center', gap:6 }}>
                <span className="dot" style={{ background:'var(--ch-ir)' }} /> observed excess (W3/W4 predicted, not fit)</span>
            </div>
          </Panel>

          <AchBoard cand={cand} onResolve={(action)=> setLocalStatus(action==='promote'?'promoted':action==='kill'?'killed':localStatus)} />
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { CandidateView });
