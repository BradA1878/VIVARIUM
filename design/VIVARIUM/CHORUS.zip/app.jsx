/* ============================================================
   CHORUS · app shell + router
   ============================================================ */
const { useState: useStateA, useEffect: useEffectA } = React;
const CA = () => window.CHORUS;

const NAV = [
  { key:'dashboard', label:'Mission Control', glyph:'◉' },
  { key:'queue',     label:'Candidate Queue', glyph:'≡' },
  { key:'sky',       label:'Sky Map',         glyph:'✦' },
  { key:'reports',   label:'CAR Reports',     glyph:'◆' },
];

function clockStr() {
  const d = new Date();
  return d.toUTCString().slice(17,25);
}

function App() {
  const parseHash = ()=>{ const h = location.hash.slice(1).split('/'); return { view: h[0]||'dashboard', id: h[1]?decodeURIComponent(h[1]):null }; };
  const [route, setRoute] = useStateA(parseHash);
  const [clock, setClock] = useStateA(clockStr());
  useEffectA(()=>{ const t=setInterval(()=>setClock(clockStr()),1000); return ()=>clearInterval(t); }, []);

  const go = (view, id=null)=>{
    setRoute({ view, id });
    location.hash = id ? `${view}/${encodeURIComponent(id)}` : view;
    const main = document.getElementById('main'); if (main) main.scrollTop = 0;
  };
  useEffectA(()=>{
    const onHash = ()=> setRoute(parseHash());
    window.addEventListener('hashchange', onHash); return ()=>window.removeEventListener('hashchange', onHash);
  }, []);

  const { view, id } = route;
  const navActive = view==='candidate'?'queue':view==='car'?'reports':view;

  let content;
  if (view==='dashboard') content = <DashboardView go={go} />;
  else if (view==='queue') content = <QueueView go={go} />;
  else if (view==='candidate') content = <CandidateView id={id} go={go} />;
  else if (view==='sky') content = <SkyView go={go} />;
  else if (view==='reports') content = <CarIndexView go={go} />;
  else if (view==='car') content = <CarView id={id} go={go} />;
  else content = <DashboardView go={go} />;

  const promoted = CA().CANDIDATES.filter(c=>c.status==='promoted').length;
  const vetting = CA().CANDIDATES.filter(c=>c.status==='vetting').length;

  return (
    <div style={{ display:'grid', gridTemplateColumns:'212px 1fr', height:'100vh' }}>
      {/* sidebar */}
      <aside style={{ borderRight:'1px solid var(--line)', display:'flex', flexDirection:'column', background:'var(--void-2)' }}>
        <div style={{ padding:'18px 18px 16px', borderBottom:'1px solid var(--line)' }}>
          <div style={{ display:'flex', alignItems:'center', gap:9 }}>
            <svg width="22" height="22" viewBox="0 0 22 22"><circle cx="11" cy="11" r="2.4" fill="var(--signal)"/>
              {[0,1,2].map(i=>(<circle key={i} cx="11" cy="11" r={5+i*3.2} fill="none" stroke={`var(${['--ch-ir','--ch-transit','--ch-radio'][i]})`} strokeWidth="1.1" strokeDasharray={`${10+i*6} ${6}`} opacity="0.9"/>))}
            </svg>
            <div>
              <div style={{ fontSize:15, letterSpacing:'0.16em', color:'var(--ink)', fontWeight:500 }}>CHORUS</div>
              <div style={{ fontSize:8, letterSpacing:'0.14em', color:'var(--ink-ghost)' }}>v0.1 · chorus-alpha</div>
            </div>
          </div>
          <p style={{ fontSize:9.5, color:'var(--ink-ghost)', marginTop:11, lineHeight:1.45 }}>Cross-survey Hunt for Objects with Residual Unexplained Signatures</p>
        </div>

        <nav style={{ padding:'10px 8px', flex:1 }}>
          {NAV.map(n=>{
            const active = navActive===n.key;
            return (
              <button key={n.key} onClick={()=>go(n.key)} style={{
                display:'flex', alignItems:'center', gap:11, width:'100%', textAlign:'left',
                padding:'10px 11px', marginBottom:2, border:'none', borderRadius:3, cursor:'pointer',
                background: active?'var(--panel-2)':'transparent', color: active?'var(--ink)':'var(--ink-faint)',
                fontFamily:'var(--mono)', fontSize:11.5, letterSpacing:'0.04em', borderLeft:`2px solid ${active?'var(--signal)':'transparent'}`,
                transition:'all .12s ease' }}
                onMouseEnter={e=>{ if(!active) e.currentTarget.style.color='var(--ink-dim)'; }}
                onMouseLeave={e=>{ if(!active) e.currentTarget.style.color='var(--ink-faint)'; }}>
                <span style={{ width:14, textAlign:'center', color: active?'var(--signal)':'var(--ink-ghost)' }}>{n.glyph}</span>
                {n.label}
              </button>
            );
          })}
        </nav>

        <div style={{ padding:'12px 16px', borderTop:'1px solid var(--line)', display:'flex', flexDirection:'column', gap:9 }}>
          <div style={{ display:'flex', justifyContent:'space-between', fontSize:10 }}>
            <span style={{ color:'var(--ink-ghost)' }}>PROMOTED</span><span className="tnum" style={{ color:'var(--signal)' }}>{promoted}</span>
          </div>
          <div style={{ display:'flex', justifyContent:'space-between', fontSize:10 }}>
            <span style={{ color:'var(--ink-ghost)' }}>VETTING</span><span className="tnum" style={{ color:'var(--amber)' }}>{vetting}</span>
          </div>
          <div className="hr" />
          <div style={{ display:'flex', alignItems:'center', gap:7, fontSize:9.5, color:'var(--ink-ghost)' }}>
            <span className="dot live" style={{ background:'var(--signal)' }} /> ENGINE LIVE
          </div>
        </div>
      </aside>

      {/* main */}
      <main id="main" style={{ overflow:'hidden', display:'flex', flexDirection:'column', minWidth:0 }}>
        {/* top bar */}
        <div className="scan" style={{ display:'flex', alignItems:'center', gap:14, padding:'0 18px', height:42, borderBottom:'1px solid var(--line)', flex:'none', background:'var(--void-2)' }}>
          <span className="eyebrow" style={{ color:'var(--ink-dim)' }}>
            {navActive==='queue'&&view==='candidate' ? 'QUEUE / CANDIDATE' : navActive==='reports'&&view==='car' ? 'REPORTS / CAR' : (NAV.find(n=>n.key===navActive)||{label:''}).label.toUpperCase()}
          </span>
          <div style={{ flex:1 }} />
          <span className="tnum" style={{ fontSize:10.5, color:'var(--ink-faint)' }}>TICK {CA().CYCLE.tick.toLocaleString()}</span>
          <span className="vr" style={{ height:16 }} />
          <span className="tnum" style={{ fontSize:10.5, color:'var(--ink-faint)' }}>{clock} UTC</span>
          <span className="vr" style={{ height:16 }} />
          <span style={{ display:'flex', alignItems:'center', gap:6, fontSize:10.5, color:'var(--ink-faint)' }}>
            <span className="dot live" style={{ background:'var(--ch-transit)' }} /> ADJUDICATE
          </span>
        </div>
        <div style={{ flex:1, minHeight:0 }}>{content}</div>
      </main>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
