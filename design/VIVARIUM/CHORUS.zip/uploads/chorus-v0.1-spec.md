# CHORUS — v0.1 Implementation Spec

**Cross-survey Hunt for Objects with Residual Unexplained Signatures**

A technosignature engine that mines public astronomical catalogs for objects anomalous across **multiple physics-independent channels**, then actively tries to kill every mundane explanation before promoting anything to a report. Forked from Sentinel; same spine, different domain.

> Core thesis: a single-channel anomaly is always debunkable. A real signature lights up several independent detectors on the *same* sky position; instrumental artifacts and astrophysical mimics almost never do. CHORUS hunts the agreement, not the individual blip.

---

## 0. Relationship to Sentinel

CHORUS is a fork of `simulacria.ai/mxf/sentinel`. The abstract shape is identical:

> cycle-driven multi-source ingestion → graph correlation → multi-hypothesis scoring → ranked report, with an ephemeral MXF agent layer on top of deterministic plumbing.

The domain swap is: financial/geo feeds → astronomical catalogs; trades → candidates; trade vetting → false-positive killing.

### Keep (port largely as-is)

| Sentinel file/dir | Role in CHORUS | Change |
|---|---|---|
| `src/graph/client.ts` | Memgraph Bolt client, graceful degradation | **As-is.** |
| `src/graph/sync.ts` | dual-write helpers (MERGE/UNWIND, APOC-free) | Generalize node/edge labels (§7). |
| `src/mxf/setup.ts` | MXF SDK bootstrap, channel, MCP tool-server registration | **As-is**, rename channel `chorus-alpha`. |
| `src/mxf/tasks.ts` | ephemeral per-task agent spin-up | As-is (agents differ). |
| `src/mxf/sentinel-tools-server.ts` | MCP tool server wrapping data APIs | Replace tool bodies with survey adapters (§4). |
| `src/scheduler/cycleRunner.ts` | tick orchestration | Model the CHORUS cycle (§8) on it. |
| `src/scheduler/heartbeat.ts` | liveness | As-is. |
| `src/mxf/agents/strategist*.ts` | tiered reasoning + ACH | → ACH adjudicator (§6). The ACH framework ports almost unchanged. |
| `src/mxf/agents/briefer.ts` | ranked report generation | → CAR generator (§9). |
| `src/mxf/agents/retrospector.ts` + `scheduler/retrospection.ts` | follow-up tracking | → "did the candidate survive reanalysis" tracker. |
| `src/db/*` (Mongo/mongoose) | source-of-truth store | Reschema to Detection/Candidate (§3, §5). |
| `src/search/*` (Meilisearch) | candidate/object search | As-is, reindex. |
| `src/slack/*` | output surface | As-is. |

### Gut (delete from the fork)

- `src/alpaca/`, `src/sim-broker/` — no trading.
- `src/scheduler/market.ts`, `position-refresh*.ts`, `strategy.ts`, `linchpin-monitor.ts` — financial cycle logic.
- `src/wolfram.ts`, `src/twitter/`, `src/discord/` — not needed for v0.1 (twitter optional later for alerts).
- The financial-domain agents (`feed-watcher` as RSS, `classifier`, `flow-scanner` bodies) — replaced by deterministic scorers + crossmatch (§5, below).

### Add (net-new, the only real new engineering)

1. **Tier 0 — spatial crossmatch** at catalog scale (§5.0). Does not exist in Sentinel.
2. **Catalog adapters** (§4) — replace RSS/market feeds.
3. **Per-channel anomaly scorers** (§5.1) — deterministic numerical, *not* LLM.

> Design rule inherited from your Vivarium split: deterministic tick engine underneath, async reasoning agent on top. In CHORUS the deterministic tier is larger and the agent tier smaller than in Sentinel — **the LLM never computes a significance.** Agents adjudicate framed evidence and write prose. That's it.

---

## 1. Tier architecture

```
                         ┌─────────────────────────────────────────┐
   PUBLIC CATALOGS       │  TIER 0 — SPATIAL CROSSMATCH (scale)      │
   Gaia DR3 (TAP) ──┐    │  HEALPix binning + per-bin k-d match.     │
   AllWISE  (IRSA) ─┼──► │  Epoch/PM propagation to common epoch.    │
   2MASS    (IRSA) ─┤    │  Out: position clusters (multi-survey).   │
   TESS/JWST (MAST)─┤    └───────────────┬───────────────────────────┘
   BL radio (BLDR) ─┘                    │ clusters
                                         ▼
                         ┌─────────────────────────────────────────┐
                         │  TIER 1 — PER-CHANNEL ANOMALY SCORERS     │
                         │  deterministic. IR-excess / transit-shape │
                         │  / drift-rate. Each emits anomScore+kind. │
                         └───────────────┬───────────────────────────┘
                                         │ anomalous detections only
                                         ▼ (promotion gate)
   MongoDB ◄──(source of truth)── ┌─────────────────────────────────┐
                                  │  TIER 2 — GRAPH (Memgraph)        │
   Meilisearch ◄──(index)──────── │  Candidate nodes + COINCIDES_WITH │
                                  │  edges + ACH Hypothesis subgraph. │
                                  │  Joint-significance query.        │
                                  └───────────────┬───────────────────┘
                                                  │ candidates w/ ≥N channels
                                                  ▼
                                  ┌─────────────────────────────────┐
                                  │  TIER 3 — MXF AGENT LAYER         │
                                  │  ACH adjudicator (Strategist).    │
                                  │  CAR generator (Briefer).         │
                                  └───────────────┬───────────────────┘
                                                  ▼
                                          CAR-xxxxxx → Slack
```

Scale note that drives the design: Hephaistos worked a ~5M-object sample. Raw crossmatch over that produces an edge explosion that **must not** enter Memgraph. Tier 0 runs in a spatial index (HEALPix + k-d tree; Postgres+Q3C or DuckDB on a single box are fine). Only detections that pass a per-channel anomaly cut get *promoted* into the graph. Memgraph holds the **candidate layer** and the **hypothesis structure**, never the firehose — exactly your existing "Mongo source-of-truth, Memgraph derived read-model" split, with a spatial tier added below.

---

## 2. Stack

- Runtime: **Bun** (as Sentinel). `tsx` dev, `tsc` build.
- Lang: TypeScript 5.x.
- Graph: **Memgraph** via `neo4j-driver` v6 (Bolt, `bolt://localhost:7687`). APOC-free.
- Store: **MongoDB** via `mongoose`.
- Search: **Meilisearch**.
- Agents: **MXF SDK** (local monorepo symlink), OpenRouter provider, **Sonnet** for adjudication/reporting (gemini-flash only for bootstrap, as Sentinel).
- Numerics: pick one and commit — Python sidecar (astropy + healpy + scipy) called via child process **or** pure-TS. **Recommendation: Python sidecar for Tier 0/1 math.** Astronomical coordinate handling (epoch propagation, frame transforms, SED fitting) is solved correctly in astropy and is a correctness minefield in hand-rolled TS. Expose the sidecar as an internal HTTP service the same way Sentinel's tool server is a separate process; agents and the cycle runner call it.
- Most survey endpoints are **keyless/anonymous** (Gaia TAP, IRSA, MAST). Fewer secrets than Sentinel.

---

## 3. The Detection model (normalization target)

Every catalog adapter normalizes into this. One row per catalog detection that passed an anomaly cut.

```ts
type Channel = 'ir_excess' | 'transit_shape' | 'radio_drift' | 'astrometric';

interface Detection {
  detectionId: string;        // `${survey}:${sourceId}`
  survey: string;             // 'gaia_dr3' | 'allwise' | '2mass' | 'tess' | 'bldr'
  channel: Channel;           // physics-independent channel this detection scores
  // position, propagated to COMMON_EPOCH (see §5.0)
  ra: number;                 // deg, ICRS, at COMMON_EPOCH
  dec: number;                // deg, ICRS, at COMMON_EPOCH
  posErrArcsec: number;       // 1-sigma positional uncertainty incl. PM-propagation error
  epochObs: number;           // original observation epoch (decimal year)
  // photometry / signal payload (channel-specific, sparse)
  bands?: Record<string, { mag?: number; magErr?: number; flux?: number }>;
  // anomaly result (Tier 1)
  anomScore: number;          // standardized; higher = more anomalous
  anomKind: string;           // e.g. 'mir_excess_w3w4'
  anomDetail: Record<string, unknown>; // model residuals, fitted params, flags
  rawRef: string;             // URL / query to reproduce
  ingestedAt: Date;
}
```

`COMMON_EPOCH` is a project constant (use **J2016.0**, Gaia's reference epoch). All positions are propagated to it.

---

## 4. Catalog adapter contract

Replaces Sentinel's RSS/market feeds. Each survey implements:

```ts
interface CatalogAdapter {
  survey: string;
  channel: Channel;
  /** Cone query, returns RAW rows (un-normalized). */
  cone(ra: number, dec: number, radiusArcsec: number): Promise<RawRow[]>;
  /** Bulk region pull for ingestion (HEALPix pixel or RA/Dec box). */
  region(pixel: HealpixPixel): Promise<RawRow[]>;
  /** Map a raw row to a partial Detection (position + bands, pre-anomaly). */
  normalize(row: RawRow): Omit<Detection, 'channel'|'anomScore'|'anomKind'|'anomDetail'> ;
}
```

v0.1 adapters (all keyless):

| Adapter | Source | Endpoint | Notes |
|---|---|---|---|
| `gaia_dr3` | ESA Gaia Archive | TAP/ADQL `gea.esac.esa.int/tap-server` | parallax, PM, G/BP/RP. Epoch 2016.0. |
| `allwise` | IRSA | TAP / catalog query | W1–W4 + `cc_flags`, `ext_flg`, variability. |
| `2mass` | IRSA | TAP / catalog query | J/H/Ks PSC. Epoch ~1999. |

Deferred adapters (later channels): `tess`/`kepler` (MAST, via astropy `astroquery.mast`), `bldr` (Breakthrough Listen Open Data REST API — see the `ggroode/bl-opendata` schema: target/telescope/utc/ra/decl/center_freq/file_type/url/md5).

---

## 5. Deterministic tiers

### 5.0 — Spatial crossmatch (Tier 0)

The **highest-risk component in the system** (see §10). Get it wrong and everything downstream is garbage.

```ts
interface CrossmatchConfig {
  commonEpoch: number;        // J2016.0
  healpixNside: number;       // e.g. 1024 (≈3.4' pixels) — tune to source density
  matchRadiusArcsec: number;  // base; effective radius = base + quadrature of posErrs
}

interface Cluster {
  clusterId: string;
  ra: number; dec: number;    // weighted centroid
  members: Detection[];       // detections from ≥1 survey
  surveys: string[];
  channels: Channel[];
}

function crossmatch(detections: Detection[], cfg: CrossmatchConfig): Cluster[];
```

Requirements:

1. **Epoch propagation before matching.** Propagate each source's position to `commonEpoch` using its proper motion (Gaia provides PM; 2MASS/WISE positions are at their own epochs). M-dwarfs are nearby and frequently high-PM — a J1999 2MASS position can be arcseconds off its J2016 position. **This is the single most common way these searches go wrong.** Sources without PM (WISE-only) carry an inflated `posErrArcsec` reflecting unknown motion over the epoch gap.
2. **Frame consistency.** Everything in ICRS. (Gaia native ICRS; 2MASS/WISE are ICRS-aligned — verify per adapter, don't assume.)
3. **Match radius is adaptive**: `r_eff = matchRadiusArcsec + sqrt(posErrA² + posErrB²)`.
4. **HEALPix bin, then k-d match within bin + neighbors** (handle pixel-boundary sources via neighbor pixels). Do not do an O(n²) all-pairs match.
5. Use **astropy `SkyCoord.apply_space_motion` + `match_to_catalog_sky`** in the sidecar. Do not hand-roll spherical trig.

### 5.1 — Per-channel anomaly scorers (Tier 1)

```ts
interface AnomalyScorer {
  channel: Channel;
  /** Score one source's normalized photometry/signal. Pure, deterministic. */
  score(input: ScorerInput): { anomScore: number; anomKind: string; anomDetail: Record<string, unknown> } | null;
  /** Hard rejection filters applied before/after scoring. */
  reject(input: ScorerInput): { rejected: boolean; reason?: string };
}
```

**v0.1 implements ONE scorer: `ir_excess`** (the validated reference, see §11).

`IrExcessScorer`:
- Input: cross-matched Gaia (parallax→distance, G/BP/RP, PM) + 2MASS (J/H/Ks) + AllWISE (W1–W4) for a source.
- Method: fit a stellar photosphere SED (empirical M-dwarf template indexed by Gaia `BP-RP`/Teff, or BT-Settl) to the optical+NIR points (**Gaia + 2MASS + W1 + W2**), **predict W3 and W4**, compute excess = observed − predicted, and a significance from photometric errors. Flag when W3/W4 excess is significant *and* the implied dust temperature / fractional luminosity sit outside the bare-photosphere regime. (Hephaistos's seven candidates were M-dwarfs with significant W3/W4 excess.)
- `reject()` filters (kill obvious mundanes up front): AllWISE `cc_flags` contamination, `ext_flg` (extended/galaxy), low photometric S/N, nearby bright source (confusion).

Deferred scorers (later): `transit_shape` (fit transit asymmetry / aperiodicity in TESS light curves — flag non-spherical-occulter shapes, the Tabby's-Star pattern), `radio_drift` (narrowband + Doppler-drift detection on BL filterbank with ON/OFF cadence — heavy DSP, big files, do last).

---

## 6. ACH — the false-positive killer

This is the heart, and it ports almost unchanged from your Strategist's ACH framework. **Analysis of Competing Hypotheses**: enumerate the explanations for an anomaly, then score each by *disconfirming* evidence. The hypothesis with the least disconfirmation wins. A candidate is promoted to a CAR **only if every natural hypothesis is disconfirmed/strongly disfavored AND the techno hypothesis survives.**

Most disconfirming tests are themselves **cross-channel queries** — which is the whole point of building this on a graph.

### ACH for the `ir_excess` channel (v0.1)

| Hypothesis | Disconfirming test (run by adjudicator via tools) |
|---|---|
| `warm_debris_disk` | M-dwarf debris disks are rare. Disfavored if fitted `T_dust` / `L_IR/L_*` fall outside the known debris-disk locus. |
| `agn_blend` | Cross-match radio surveys (VLASS / NVSS / RACS) at the Gaia position; check WISE centroid shift across W1→W4 (a blend's centroid migrates toward the contaminant in longer bands). Detection ⇒ disconfirms techno. *(This is exactly the test that killed Hephaistos candidate G.)* |
| `young_stellar / protoplanetary` | Check NEOWISE W1/W2 light curve for variability and youth/SFR association by galactic latitude. YSOs vary; the candidates of interest do not. |
| `data_artifact / confusion` | AllWISE contamination & confusion flags, nearby bright source, image inspection / confusion score. |
| `techno_ir_excess` | Survives all of the above. **Not a positive detection of aliens — a residual unexplained signature.** |

```ts
interface Hypothesis {
  kind: string;               // 'warm_debris_disk' | 'agn_blend' | ...
  prior: number;
  posterior: number;          // updated after disconfirming tests
  disconfirmed: boolean;
  evidence: Array<{ test: string; result: string; effect: 'disconfirm'|'support'|'neutral' }>;
}

interface AchResult {
  candidateId: string;
  hypotheses: Hypothesis[];
  surviving: string[];        // not disconfirmed
  promote: boolean;           // true iff naturals disconfirmed AND techno survives
}
```

The adjudicator (Sonnet) **frames and orders** the evidence and writes the rationale. The numbers (radio match? centroid shift in arcsec? variability amplitude?) come from deterministic tools. The LLM does not invent a significance.

---

## 7. Graph schema (Memgraph, APOC-free)

```
(:Detection {detectionId, survey, channel, ra, dec, posErrArcsec, epochObs, anomScore, anomKind})
(:Candidate {clusterId, ra, dec, nChannels, jointFAP, status})   // status: 'open'|'vetting'|'promoted'|'killed'
(:Hypothesis {kind, prior, posterior, disconfirmed})

(:Candidate)-[:SUPPORTED_BY]->(:Detection)
(:Candidate)-[:EXPLAINED_BY {disconfirmingEvidence, score}]->(:Hypothesis)
(:Detection)-[:COINCIDES_WITH {sepArcsec, dtDays}]->(:Detection)
```

Spatial clustering happens in Tier 0; CHORUS creates one `Candidate` per cluster and links `SUPPORTED_BY`. No graph-side geometry. Generalize Sentinel's `sync.ts` `Entity` label to these node types; reuse the sanitized-rel-type interpolation (Memgraph can't parameterize rel types in MERGE) and the UNWIND batch path verbatim.

**Candidate query (the CAR queue):**

```cypher
MATCH (c:Candidate)-[:SUPPORTED_BY]->(d:Detection)
WITH c, count(DISTINCT d.channel) AS nch, collect(DISTINCT d.survey) AS surveys
WHERE nch >= 3
  AND NOT (c)-[:EXPLAINED_BY {disconfirmed: false}]->(:Hypothesis)  // no surviving natural explanation
RETURN c, nch, surveys
ORDER BY c.jointFAP ASC
```

> v0.1 caveat: with a single channel implemented, `nch >= 3` returns nothing by design. v0.1's gate is therefore §11 (reproduce Hephaistos on the `ir_excess` channel alone). The `nch >= 3` join is the v0.2+ payoff once a second and third channel exist; the schema is built for it now so the spine doesn't change later.

---

## 8. The cycle (Tier orchestration)

Model on `cycleRunner.ts`. Per tick:

1. **Ingest deltas** — for each HEALPix pixel due for refresh, pull via adapters (`region()`), normalize.
2. **Crossmatch** — Tier 0 over the pixel + neighbors → clusters.
3. **Score** — Tier 1 scorers on cluster members; persist Detections to Mongo (source of truth) with `anomScore`.
4. **Promote** — detections passing the anomaly cut → upsert Candidate + SUPPORTED_BY into Memgraph (dual-write, fire-and-forget, per `sync.ts`).
5. **Adjudicate** — for Candidates in `open`/`vetting`, spin an ephemeral ACH agent (Tier 3); run disconfirming tests; write Hypothesis subgraph; set `promote`.
6. **Report** — promoted Candidates → CAR generator → Slack.
7. **Retrospect** — re-run vetting on aging promoted candidates (new data may disconfirm).

Transient streams (ZTF/Rubin), when added, are a **separate always-on subscriber path**, not part of the batch tick — they feed Detections in at step 3.

---

## 9. CAR — output schema

Mirrors Sentinel's Briefer output. `CAR-xxxxxx` reference (six hex). Yes, it rhymes with the DRC's Coherence Anomaly Reports — here it points at real photons.

```ts
interface CoherenceAnomalyReport {
  ref: string;                // CAR-A1B2C3
  candidateId: string;
  position: { ra: number; dec: number; constellation?: string };
  channels: Channel[];        // which independent channels fired
  jointFAP: number;           // joint false-alarm probability, look-elsewhere corrected (§10)
  survivingHypothesis: string;
  disconfirmed: Array<{ kind: string; evidence: string }>;
  recommendedFollowup: string[]; // e.g. "high-res radio imaging at position", "JWST spectroscopy"
  reproducibility: string[];     // the exact queries/URLs to regenerate every input
  generatedAt: Date;
}
```

---

## 10. Risk flags (read before implementing)

Ordered by severity. The first two are the RegNo-parser-equivalents — the components most likely to silently corrupt everything.

1. **Coordinate crossmatch correctness (§5.0).** Epoch/PM propagation and frame consistency. A missed J1999→J2016 propagation on a high-PM M-dwarf manufactures or destroys coincidences. **Mitigation:** astropy in the sidecar; never hand-roll; unit-test against known-PM stars with hand-verified cross-epoch positions.
2. **WISE confusion / blending in crowded fields.** The Hephaistos *follow-up* debunk was about background-AGN contamination and centroid drift across W1→W4. **Mitigation:** `cc_flags`/`ext_flg` rejection up front; centroid-shift test is a first-class ACH disconfirmer, not an afterthought.
3. **Look-elsewhere / multiple testing.** 5M objects × N channels = an enormous trials factor. A "3-sigma" per-object result is meaningless without it. **Mitigation:** `jointFAP` must be trials-corrected (FDR or equivalent); bake the trials count into the significance, not the prose.
4. **Red noise / instrumental systematics.** The K2-18b lesson: features near the noise floor get over-interpreted; independent reductions collapsed a 3-sigma "biosignature." **Mitigation:** for any spectral/time-series channel, require robustness across reduction choices before promotion.
5. **LLM boundary.** Agents adjudicate framed evidence and write reports. **They never compute crossmatch significance, FAP, or SED residuals.** Enforce in code: the ACH agent's tools return numbers; the agent cannot fabricate them.

---

## 11. v0.1 scope cut + validation gate

**v0.1 = one vertical slice, end to end, validated against a known result.**

In scope:
- Tier 0 crossmatch: Gaia DR3 × 2MASS × AllWISE, epoch-propagated to J2016.0.
- Tier 1: `IrExcessScorer` only.
- Tier 2: graph schema + dual-write + Candidate creation (single-channel; `nch>=3` query stubbed for later).
- Tier 3: ACH adjudicator with the `ir_excess` hypothesis set (§6); CAR generator; Slack output.
- Mongo store, Meili index, MXF bootstrap (channel `chorus-alpha`), Python numerics sidecar.

Deferred to v0.2+:
- `transit_shape` channel (TESS/MAST).
- `radio_drift` channel (BL Open Data) — heaviest; do last.
- Transient stream subscriber (ZTF/Rubin).
- The multi-channel `nch>=3` promotion path going live.

**Acceptance criterion (the gate):** running the v0.1 pipeline over the Hephaistos input footprint (Gaia DR3 sources within 300 pc, M-dwarfs, cross-matched to 2MASS + AllWISE) **reproduces Hephaistos's seven IR-excess candidates** — or explains every divergence (different cut, flag, or SED model). This is the "validated genetics engine" move from the Nihon Ken build: prove the deterministic core against a published reference before trusting it on anything new. If v0.1 can't recover seven known candidates, the crossmatch or the scorer is wrong, and no amount of v0.2 channels will save it.

---

## 12. Build order for Claude Code

1. Scaffold the fork; gut the financial modules (§0); stand up Mongo + Memgraph + Meili + the Python sidecar locally (docker-compose).
2. `gaia_dr3` adapter → verify a cone query returns sane PM/parallax.
3. Tier 0 `crossmatch()` in the sidecar (astropy) → unit-test cross-epoch propagation on known-PM stars. **Do not proceed until this passes.**
4. `2mass` + `allwise` adapters; full three-way crossmatch over a test pixel.
5. `IrExcessScorer` → fit/predict/residual; reject filters.
6. Graph dual-write (port `sync.ts`); Candidate creation; Meili index.
7. MXF bootstrap (port `setup.ts`); ACH adjudicator agent + disconfirming-test tools (radio cross-match, centroid-shift, NEOWISE variability).
8. CAR generator (port `briefer.ts`) + Slack.
9. **Run the §11 gate.** Iterate on crossmatch/scorer until the seven candidates reproduce.
