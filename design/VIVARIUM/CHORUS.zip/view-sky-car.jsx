/* ============================================================
   VIEW · SKY MAP (Hammer projection) + CAR REPORT
   ============================================================ */
const { useState: useStateS, useMemo: useMemoS } = React;
const CS = () => window.CHORUS;

/* ---- Hammer equal-area projection ---- */
function hammer(raDeg, decDeg) {
  let a = raDeg > 180 ? raDeg - 360 : raDeg;        // [-180,180]
  const lam = a * Math.PI/180, phi = decDeg * Math.PI/180;
  const d = Math.sqrt(1 + Math.cos(phi)*Math.cos(lam/2));
  const x = (2*Math.SQRT2 * Math.cos(phi) * Math.sin(lam/2)) / d; // [-2√2,2√2]
  const y = (Math.SQRT2 * Math.sin(phi)) / d;                      // [-√2,√2]
  return { x: 0.5 - x/(4*Math.SQRT2), y: 0.5 - y/(2*Math.SQRT2) };  // 0..1, y flipped
}

function SkyView({ go }) {
  const cands = CS().CANDIDATES;
  const [hover, setHover] = useStateS(null);
  const [colorBy, setColorBy] = useStateS('status');
  const W = 760, H = 392, pad = 14;
  const px = (u)=> pad + u*(W-2*pad);
  const py = (u)=> pad + u*(H-2*pad);

  // graticule
  const meridians = [-150,-120,-90,-60,-30,0,30,60,90,120,150];
  const parallels = [-60,-30,0,30,60];
  const samp = (fn)=>{ const pts=[]; for(let i=0;i<=64;i++){ pts.push(fn(i/64)); } return pts; };
  const path = (pts)=> pts.map((p,i)=>`${i?'L':'M'} ${px(p.x).toFixed(1)} ${py(p.y).toFixed(1)}`).join(' ');

  const statusCol = (c)=> (window.STATUS_META[c.status]||window.STATUS_META.open).col;
  const chCol = (c)=> c.nChannels>=3?'var(--signal)':c.nChannels>=2?'var(--amber)':`var(${CS().CHANNELS[c.channels[0]].varName})`;
  const dotCol = (c)=> colorBy==='status'?statusCol(c):chCol(c);

  return (
    <div className="scroll" style={{ height:'100%', padding:18 }}>
      <div style={{ display:'grid', gridTemplateColumns:'minmax(560px, 2fr) minmax(240px, 0.9fr)', gap:16, alignItems:'start' }}>
        <Panel>
          <Strip label="SKY MAP · ICRS @ J2016.0 · Hammer projection" accent="var(--ch-transit)" right={
            <div style={{ display:'flex', gap:6 }}>
              {['status','channels'].map(m=>(
                <button key={m} className={`btn ${colorBy===m?'btn--primary':''}`} style={{ fontSize:9.5, padding:'4px 9px' }} onClick={()=>setColorBy(m)}>color: {m}</button>
              ))}
            </div>
          } />
          <div style={{ padding:14, position:'relative' }}>
            <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{ display:'block', background:'radial-gradient(ellipse at 50% 45%, var(--void-2), var(--void))', borderRadius:3 }}>
              {/* outer ellipse boundary */}
              <path d={path(samp(t=>hammer(-179.99 + 359.98*t, 90)).concat(samp(t=>hammer(-179.99+359.98*t,-90)).reverse()))} fill="none" stroke="var(--line)" strokeWidth="1" />
              {/* parallels */}
              {parallels.map(d=>(
                <path key={'p'+d} d={path(samp(t=>hammer(-179.99 + 359.98*t, d)))} fill="none" stroke="var(--line-soft)" strokeWidth="0.7" />
              ))}
              {/* meridians */}
              {meridians.map(a=>(
                <path key={'m'+a} d={path(samp(t=>hammer(a<0?a+360:a, -90 + 180*t)))} fill="none" stroke="var(--line-soft)" strokeWidth="0.7" />
              ))}
              {/* dec labels */}
              {parallels.map(d=>{ const p=hammer(0,d); return <text key={'dl'+d} x={px(p.x)+3} y={py(p.y)-2} fontSize="8" fill="var(--ink-ghost)" fontFamily="var(--mono)">{d>0?'+':''}{d}°</text>; })}

              {/* candidates */}
              {cands.map(c=>{
                const p = hammer(c.ra, c.dec); const X=px(p.x), Y=py(p.y); const col=dotCol(c);
                const hovered = hover && hover.id===c.id;
                const r = 3 + c.nChannels*1.6;
                return (
                  <g key={c.id} style={{ cursor:'pointer' }} onClick={()=>go('candidate', c.id)}
                     onMouseEnter={()=>setHover(c)} onMouseLeave={()=>setHover(null)}>
                    {c.nChannels>=2 && <circle cx={X} cy={Y} r={r+5} fill="none" stroke={col} strokeWidth="0.8" opacity="0.5" />}
                    <circle cx={X} cy={Y} r={hovered?r+2:r} fill={col} fillOpacity={c.status==='killed'?0.35:0.85} stroke="var(--void)" strokeWidth="1"
                      style={{ filter:`drop-shadow(0 0 ${hovered?6:3}px ${col})` }} />
                    {c.status==='killed' && <line x1={X-r} y1={Y-r} x2={X+r} y2={Y+r} stroke="var(--red)" strokeWidth="1.2" />}
                  </g>
                );
              })}
            </svg>
            {hover && (()=>{ const p=hammer(hover.ra,hover.dec); return (
              <div style={{ position:'absolute', left:`calc(${(px(p.x)/W)*100}% )`, top:py(p.y)+10, transform:'translateX(-50%)',
                background:'var(--raised)', border:'1px solid var(--line-bright)', borderRadius:3, padding:'8px 10px', pointerEvents:'none', zIndex:9, minWidth:160, boxShadow:'var(--shadow)' }}>
                <div style={{ display:'flex', alignItems:'center', gap:8 }}><span style={{ fontSize:11.5, color:'var(--ink)' }}>{hover.id}</span><StatusBadge status={hover.status} /></div>
                <div className="tnum" style={{ fontSize:9.5, color:'var(--ink-faint)', margin:'4px 0' }}>{fmtCoord(hover.ra,hover.dec)} · {hover.constellation}</div>
                <div style={{ display:'flex', gap:4 }}><ChannelRow channels={hover.channels} size={16} /></div>
              </div>
            ); })()}
          </div>
        </Panel>

        {/* legend + list */}
        <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
          <Panel>
            <Strip label="LEGEND" />
            <div style={{ padding:'12px 14px', display:'flex', flexDirection:'column', gap:8 }}>
              {colorBy==='status'
                ? Object.entries(window.STATUS_META).map(([k,m])=>(
                    <div key={k} style={{ display:'flex', alignItems:'center', gap:9 }}><span className="dot" style={{ background:m.col }} /><span style={{ fontSize:11, color:'var(--ink-dim)' }}>{m.label}</span></div>))
                : <>
                    <div style={{ display:'flex', alignItems:'center', gap:9 }}><span className="dot" style={{ background:'var(--signal)' }} /><span style={{ fontSize:11, color:'var(--ink-dim)' }}>3+ channels (promotable)</span></div>
                    <div style={{ display:'flex', alignItems:'center', gap:9 }}><span className="dot" style={{ background:'var(--amber)' }} /><span style={{ fontSize:11, color:'var(--ink-dim)' }}>2 channels</span></div>
                    <div style={{ display:'flex', alignItems:'center', gap:9 }}><span className="dot" style={{ background:'var(--ch-ir)' }} /><span style={{ fontSize:11, color:'var(--ink-dim)' }}>1 channel (by type)</span></div>
                  </>}
              <div className="hr" style={{ margin:'4px 0' }} />
              <div style={{ fontSize:10, color:'var(--ink-ghost)', lineHeight:1.5 }}>Marker size ∝ N channels · halo = multi-channel agreement · ✕ = killed</div>
            </div>
          </Panel>
          <Panel>
            <Strip label="ALL CANDIDATES" right={<span className="eyebrow">{cands.length}</span>} />
            <div className="scroll" style={{ maxHeight:300 }}>
              {cands.map(c=>(
                <div key={c.id} className="row" onClick={()=>go('candidate', c.id)} onMouseEnter={()=>setHover(c)} onMouseLeave={()=>setHover(null)}
                  style={{ display:'flex', alignItems:'center', gap:9, padding:'8px 13px', borderBottom:'1px solid var(--line-soft)' }}>
                  <span className="dot" style={{ background:dotCol(c) }} />
                  <span style={{ fontSize:11, color:'var(--ink-dim)', flex:1 }}>{c.id}</span>
                  <span style={{ fontSize:9.5, color:'var(--ink-ghost)' }}>{c.constellation}</span>
                </div>
              ))}
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   CAR REPORT (read-only dossier) + index
   ============================================================ */
function CarIndexView({ go }) {
  const cars = CS().CANDIDATES.filter(c=>c.car);
  return (
    <div className="scroll" style={{ height:'100%', padding:18 }}>
      <Panel>
        <Strip label="COHERENCE ANOMALY REPORTS · posted to #chorus-alpha" accent="var(--signal)" right={<span className="eyebrow">{cars.length} REPORTS</span>} />
        {cars.map(c=>(
          <div key={c.id} className="row" onClick={()=>go('car', c.id)} style={{ display:'flex', alignItems:'center', gap:14, padding:'13px 16px', borderBottom:'1px solid var(--line-soft)' }}>
            <span style={{ fontSize:14, color:'var(--signal)', width:110 }}>{c.car.ref}</span>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:11.5, color:'var(--ink)' }}>{c.id} {c.hepRef&&`· HEP ${c.hepRef}`}</div>
              <div className="tnum" style={{ fontSize:10, color:'var(--ink-ghost)', marginTop:2 }}>{fmtCoord(c.ra,c.dec)} · {c.constellation}</div>
            </div>
            <ChannelRow channels={c.channels} size={18} />
            <span className="tnum" style={{ fontSize:11, color:'var(--ink-dim)', width:70, textAlign:'right' }}>{CS().fmtFAP(c.jointFAP)}</span>
            <span style={{ color:'var(--ink-ghost)' }}>›</span>
          </div>
        ))}
      </Panel>
    </div>
  );
}

function CarView({ id, go }) {
  const cand = CS().candidateById(id);
  if (!cand || !cand.car) return <CarIndexView go={go} />;
  const car = cand.car;
  const disc = cand.ach.hypotheses.filter(h=>h.disconfirmed && !h.kind.startsWith('techno'));
  const surviving = cand.ach.hypotheses.find(h=>h.kind.startsWith('techno'));

  const Sec = ({ n, label, children }) => (
    <div style={{ display:'flex', gap:16, padding:'16px 0', borderTop:'1px solid var(--line-soft)' }}>
      <div style={{ width:90, flex:'none' }}><span className="eyebrow">{n} · {label}</span></div>
      <div style={{ flex:1, minWidth:0 }}>{children}</div>
    </div>
  );

  return (
    <div className="scroll" style={{ height:'100%', padding:'18px', display:'flex', justifyContent:'center' }}>
      <div style={{ width:'100%', maxWidth:860 }}>
        <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:14 }}>
          <button className="btn btn--ghost" onClick={()=>go('reports')}>← reports</button>
          <div style={{ flex:1 }} />
          <button className="btn" onClick={()=>go('candidate', cand.id)}>open adjudication →</button>
        </div>

        <Panel>
          {/* masthead */}
          <div style={{ padding:'20px 24px', borderBottom:'1px solid var(--line)', background:'linear-gradient(180deg, color-mix(in oklch, var(--signal), var(--void) 92%), transparent)' }}>
            <div style={{ display:'flex', alignItems:'flex-start', gap:20 }}>
              <ConvergenceTarget channels={cand.channels} status="promoted" size={96} animate={false} />
              <div style={{ flex:1 }}>
                <div className="eyebrow" style={{ color:'var(--signal-dim)' }}>COHERENCE ANOMALY REPORT</div>
                <div style={{ fontSize:30, color:'var(--signal)', letterSpacing:'0.02em', margin:'2px 0 6px' }}>{car.ref}</div>
                <div className="tnum" style={{ fontSize:12, color:'var(--ink-dim)' }}>{cand.id} · {cand.gaiaId}</div>
                <div className="tnum" style={{ fontSize:11, color:'var(--ink-faint)', marginTop:3 }}>generated {car.generatedAt} · channel chorus-alpha</div>
              </div>
              <span className="chip is-promoted" style={{ alignSelf:'flex-start' }}>PROMOTED</span>
            </div>
          </div>

          <div style={{ padding:'4px 24px 20px' }}>
            <Sec n="01" label="POSITION">
              <div className="tnum" style={{ fontSize:15, color:'var(--ink)' }}>{fmtCoord(cand.ra,cand.dec)}</div>
              <div style={{ fontSize:11, color:'var(--ink-faint)', marginTop:3 }}>{cand.constellation} · {cand.distance_pc} pc · Teff {cand.teff}K · ICRS @ J2016.0</div>
            </Sec>

            <Sec n="02" label="CHANNELS">
              <div style={{ display:'flex', gap:8, alignItems:'center', flexWrap:'wrap' }}>
                {cand.channels.map(ch=>(
                  <span key={ch} className="chip" style={{ color:`var(${CS().CHANNELS[ch].varName})`, borderColor:`color-mix(in oklch, var(${CS().CHANNELS[ch].varName}), transparent 60%)` }}>
                    <ChannelGlyph ch={ch} size={16} />{CS().CHANNELS[ch].label}</span>
                ))}
                <span style={{ flex:1 }} />
                <div style={{ textAlign:'right' }}>
                  <span className="eyebrow">JOINT FAP (LEE-corrected)</span>
                  <div className="tnum" style={{ fontSize:16, color:'var(--signal)' }}>{CS().fmtFAP(cand.jointFAP)}</div>
                </div>
              </div>
            </Sec>

            <Sec n="03" label="SURVIVING">
              <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                <span style={{ fontSize:13.5, color:'var(--signal)' }}>◆ {HYP_LABEL[surviving.kind]}</span>
                <span className="chip is-promoted" style={{ fontSize:8.5 }}>NOT DISCONFIRMED</span>
              </div>
              <p className="sans" style={{ fontSize:12, color:'var(--ink-dim)', marginTop:6, lineHeight:1.5, textWrap:'pretty' }}>
                A residual unexplained signature — <b>not</b> a positive detection. Every natural hypothesis below was disconfirmed or strongly disfavored by deterministic cross-channel tests; the techno hypothesis is what remains.
              </p>
            </Sec>

            <Sec n="04" label="DISCONFIRMED">
              <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
                {disc.map(h=>(
                  <div key={h.kind} style={{ display:'flex', gap:10, padding:'8px 11px', background:'var(--void)', border:'1px solid var(--line-soft)', borderRadius:3 }}>
                    <span style={{ color:'var(--red)', fontSize:11, width:160, flex:'none', textDecoration:'line-through', textDecorationColor:'var(--red-dim)' }}>{HYP_LABEL[h.kind]}</span>
                    <span className="sans" style={{ fontSize:11, color:'var(--ink-dim)', lineHeight:1.45 }}>{h.evidence.filter(e=>e.effect==='disconfirm').map(e=>e.result).join(' · ')||h.evidence.map(e=>e.result).join(' · ')}</span>
                  </div>
                ))}
              </div>
            </Sec>

            <Sec n="05" label="FOLLOW-UP">
              <ol style={{ margin:0, paddingLeft:18, display:'flex', flexDirection:'column', gap:5 }}>
                {car.recommendedFollowup.map((f,i)=><li key={i} className="sans" style={{ fontSize:12, color:'var(--ink-dim)', lineHeight:1.45 }}>{f}</li>)}
              </ol>
            </Sec>

            <Sec n="06" label="REPRODUCE">
              <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
                {car.reproducibility.map((r,i)=>(
                  <div key={i} style={{ fontSize:10.5, color:'var(--ink-faint)', padding:'7px 10px', background:'var(--void)', border:'1px solid var(--line-soft)', borderRadius:3, wordBreak:'break-all', lineHeight:1.4 }}>
                    <span style={{ color:'var(--ink-ghost)' }}>$ </span>{r}</div>
                ))}
              </div>
              <div style={{ fontSize:9.5, color:'var(--ink-ghost)', marginTop:8 }}>Every input is regenerable from these queries · LLM computed none of the numbers above (§10.5)</div>
            </Sec>
          </div>
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { SkyView, CarIndexView, CarView });
