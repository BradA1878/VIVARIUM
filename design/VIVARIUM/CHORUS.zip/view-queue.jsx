/* ============================================================
   VIEW · CANDIDATE QUEUE (the CAR queue)
   ============================================================ */
const { useState: useStateQ, useMemo: useMemoQ } = React;
const CQ = () => window.CHORUS;

function QueueView({ go }) {
  const all = CQ().CANDIDATES;
  const [statusF, setStatusF] = useStateQ('all');
  const [chF, setChF] = useStateQ('all');
  const [sort, setSort] = useStateQ({ key:'jointFAP', dir:1 });

  const counts = useMemoQ(()=>{
    const c = { all: all.length, promoted:0, vetting:0, open:0, killed:0 };
    all.forEach(x=>c[x.status]++); return c;
  }, [all]);

  const rows = useMemoQ(()=>{
    let r = all.filter(c => (statusF==='all'||c.status===statusF) && (chF==='all'||c.channels.includes(chF)));
    r = [...r].sort((a,b)=>{
      let av=a[sort.key], bv=b[sort.key];
      if (sort.key==='channels') { av=a.nChannels; bv=b.nChannels; }
      return (av>bv?1:av<bv?-1:0)*sort.dir;
    });
    return r;
  }, [all, statusF, chF, sort]);

  const setSortKey = (key)=> setSort(s=> s.key===key ? {key, dir:-s.dir} : {key, dir:1});
  const arrow = (key)=> sort.key===key ? (sort.dir>0?' ▲':' ▼') : '';

  const Th = ({k, children, style}) => (
    <th onClick={k?()=>setSortKey(k):undefined} style={{ textAlign:'left', padding:'9px 12px', fontSize:9.5, letterSpacing:'0.12em',
      color:'var(--ink-faint)', fontWeight:500, cursor:k?'pointer':'default', userSelect:'none', whiteSpace:'nowrap', ...style }}>
      {children}<span style={{ color:'var(--signal)' }}>{k?arrow(k):''}</span>
    </th>
  );

  return (
    <div className="scroll" style={{ height:'100%', padding:18 }}>
      {/* filter bar */}
      <div style={{ display:'flex', alignItems:'center', gap:18, marginBottom:14, flexWrap:'wrap' }}>
        <div>
          <span className="eyebrow" style={{ display:'block', marginBottom:6 }}>STATUS</span>
          <div style={{ display:'flex', gap:6 }}>
            {['all','promoted','vetting','open','killed'].map(s=>(
              <button key={s} className={`btn ${statusF===s?'btn--primary':''}`} style={{ fontSize:10, padding:'5px 10px' }}
                onClick={()=>setStatusF(s)}>{s}<span style={{ opacity:0.6, marginLeft:5 }}>{counts[s]}</span></button>
            ))}
          </div>
        </div>
        <div className="vr" style={{ height:38 }} />
        <div>
          <span className="eyebrow" style={{ display:'block', marginBottom:6 }}>CHANNEL FIRED</span>
          <div style={{ display:'flex', gap:6 }}>
            <button className={`btn ${chF==='all'?'btn--primary':''}`} style={{ fontSize:10, padding:'5px 10px' }} onClick={()=>setChF('all')}>all</button>
            {Object.keys(CQ().CHANNELS).map(ch=>(
              <button key={ch} className="btn" style={{ fontSize:10, padding:'5px 8px',
                ...(chF===ch?{ borderColor:`var(${CQ().CHANNELS[ch].varName})`, color:`var(${CQ().CHANNELS[ch].varName})` }:{}) }}
                onClick={()=>setChF(chF===ch?'all':ch)}><ChannelGlyph ch={ch} size={16} dim={chF!==ch&&chF!=='all'?false:false} />{CQ().CHANNELS[ch].short}</button>
            ))}
          </div>
        </div>
        <div style={{ flex:1 }} />
        <div style={{ textAlign:'right' }}>
          <div className="tnum" style={{ fontSize:20, color:'var(--ink)' }}>{rows.length}</div>
          <div className="eyebrow">CANDIDATES</div>
        </div>
      </div>

      {/* v0.1 caveat banner */}
      <div style={{ display:'flex', gap:10, alignItems:'center', padding:'8px 13px', marginBottom:12,
        border:'1px solid color-mix(in oklch, var(--amber), transparent 65%)', borderRadius:3,
        background:'color-mix(in oklch, var(--amber), var(--void) 90%)' }}>
        <span className="dot" style={{ background:'var(--amber)' }} />
        <span className="sans" style={{ fontSize:11.5, color:'var(--ink-dim)' }}>
          <b style={{ color:'var(--amber)' }}>v0.1 gate.</b> Only <code>ir_excess</code> is live, so the <code>nch≥3</code> promotion path returns nothing by design.
          Single-channel candidates are vetted against the Hephaistos reference set. Multi-channel rows preview the v0.2 payoff.
        </span>
      </div>

      <Panel>
        <table style={{ width:'100%', borderCollapse:'collapse' }}>
          <thead><tr style={{ borderBottom:'1px solid var(--line)' }}>
            <Th>CLUSTER</Th>
            <Th>POSITION · ICRS @ J2016</Th>
            <Th k="channels" style={{ textAlign:'center' }}>CHANNELS</Th>
            <Th k="nChannels" style={{ textAlign:'right' }}>N<sub>ch</sub></Th>
            <Th k="anomScore" style={{ textAlign:'right' }}>ANOM</Th>
            <Th k="jointFAP" style={{ textAlign:'right' }}>JOINT FAP</Th>
            <Th>STATUS</Th>
            <Th style={{ width:30 }}></Th>
          </tr></thead>
          <tbody>
            {rows.map(c=>(
              <tr key={c.id} className="row" onClick={()=>go('candidate', c.id)} style={{ borderBottom:'1px solid var(--line-soft)' }}>
                <td style={{ padding:'11px 12px' }}>
                  <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                    <span style={{ color:'var(--ink)', fontSize:12 }}>{c.id}</span>
                    {c.hepRef && <span className="chip" style={{ fontSize:8.5, padding:'1px 5px', color:'var(--ink-faint)' }}>HEP·{c.hepRef}</span>}
                  </div>
                  <div style={{ fontSize:9.5, color:'var(--ink-ghost)', marginTop:2 }}>{c.gaiaId.replace('Gaia DR3','GDR3')}</div>
                </td>
                <td style={{ padding:'11px 12px' }}>
                  <div className="tnum" style={{ fontSize:11.5, color:'var(--ink-dim)' }}>{fmtCoord(c.ra,c.dec)}</div>
                  <div style={{ fontSize:9.5, color:'var(--ink-ghost)', marginTop:2 }}>{c.constellation} · {c.distance_pc}pc · {c.teff}K</div>
                </td>
                <td style={{ padding:'11px 12px' }}><div style={{ display:'flex', justifyContent:'center' }}><ChannelRow channels={c.channels} size={20} /></div></td>
                <td style={{ padding:'11px 12px', textAlign:'right' }}>
                  <span className="tnum" style={{ fontSize:13, color: c.nChannels>=3?'var(--signal)':c.nChannels>=2?'var(--amber)':'var(--ink-dim)' }}>{c.nChannels}</span>
                </td>
                <td style={{ padding:'11px 12px', textAlign:'right' }}><span className="tnum" style={{ fontSize:12, color:'var(--ink-dim)' }}>{c.anomScore.toFixed(1)}σ</span></td>
                <td style={{ padding:'11px 12px', textAlign:'right' }}><span className="tnum" style={{ fontSize:12, color:'var(--ink-dim)' }}>{CQ().fmtFAP(c.jointFAP)}</span></td>
                <td style={{ padding:'11px 12px' }}><StatusBadge status={c.status} pulse /></td>
                <td style={{ padding:'11px 12px', color:'var(--ink-ghost)' }}>›</td>
              </tr>
            ))}
          </tbody>
        </table>
        {rows.length===0 && <div style={{ padding:'34px', textAlign:'center', color:'var(--ink-ghost)', fontSize:12 }}>no candidates match the filter</div>}
      </Panel>
    </div>
  );
}

Object.assign(window, { QueueView });
