/* ============================================================
   CHORUS synthetic dataset
   Anchored on the Hephaistos seven (IR-excess M-dwarfs, incl. the
   killed candidate G) + two richer multi-channel candidates that
   preview the v0.2 nch>=3 promotion path.
   All numbers plausible, not authoritative.
   ============================================================ */
(function () {
  // ---- channel registry -----------------------------------------------
  const CHANNELS = {
    ir_excess:    { key:'ir_excess',    label:'IR EXCESS',   short:'IR', survey:'AllWISE', wl:'12–22µm',  varName:'--ch-ir' },
    transit_shape:{ key:'transit_shape',label:'TRANSIT',     short:'TR', survey:'TESS',    wl:'0.6–1µm',  varName:'--ch-transit' },
    radio_drift:  { key:'radio_drift',  label:'RADIO DRIFT', short:'RD', survey:'BL/GBT',  wl:'1–8GHz',   varName:'--ch-radio' },
    astrometric:  { key:'astrometric',  label:'ASTROMETRIC', short:'AS', survey:'Gaia DR3',wl:'0.5µm',    varName:'--ch-astro' },
  };

  // ---- SED generator (M-dwarf photosphere + MIR excess) ---------------
  // central wavelengths (µm)
  const BANDS = [
    { name:'BP', wl:0.511, src:'gaia' }, { name:'G', wl:0.621, src:'gaia' }, { name:'RP', wl:0.777, src:'gaia' },
    { name:'J', wl:1.235, src:'2mass' }, { name:'H', wl:1.662, src:'2mass' }, { name:'Ks', wl:2.159, src:'2mass' },
    { name:'W1', wl:3.353, src:'wise' }, { name:'W2', wl:4.603, src:'wise' }, { name:'W3', wl:11.56, src:'wise' }, { name:'W4', wl:22.09, src:'wise' },
  ];
  // blackbody-ish nuFnu shape, normalized to peak
  function bbNuFnu(wl, T) { const x = 14387.7 / (wl * T); return (1 / Math.pow(wl, 4)) / (Math.exp(x) - 1); }
  function makeSED(teff, excess) {
    // excess: { W2?:f, W3:f, W4:f }  multiplicative bumps
    const peak = Math.max(...BANDS.map(b => bbNuFnu(b.wl, teff)));
    return BANDS.map(b => {
      const model = bbNuFnu(b.wl, teff) / peak;          // 0..1
      const bump = (excess && excess[b.name]) ? excess[b.name] : 0;
      const obs = model * (1 + bump);
      const logModel = Math.log10(model);
      const logObs = Math.log10(obs);
      const err = 0.018 + (b.src === 'wise' ? 0.02 : 0.008) + (b.name === 'W4' ? 0.03 : 0);
      return { ...b, logModel, logObs, err, excess: bump };
    });
  }

  // ---- ACH hypothesis templates ---------------------------------------
  // effect: 'disconfirm' lowers posterior; 'support' raises; 'neutral'
  function hyp(kind, prior, evidence, posterior, disconfirmed) {
    return { kind, prior, posterior, disconfirmed, evidence };
  }

  // standard ir_excess hypothesis set, parameterized by outcome
  function irAch(outcome) {
    if (outcome === 'promote') {
      return {
        promote: true,
        hypotheses: [
          hyp('warm_debris_disk', 0.34, [
            { test:'T_dust / L_IR÷L_* locus', result:'T_dust=148K, L_IR/L_*=2.1e-2 — outside M-dwarf debris locus (>10σ rare)', effect:'disconfirm' },
          ], 0.04, true),
          hyp('agn_blend', 0.22, [
            { test:'VLASS / NVSS / RACS crossmatch @ pos', result:'no radio source within 8″ (RACS 3σ < 0.9 mJy)', effect:'disconfirm' },
            { test:'WISE centroid shift W1→W4', result:'Δ = 0.18″ ± 0.21″ — consistent with zero', effect:'disconfirm' },
          ], 0.02, true),
          hyp('young_stellar', 0.18, [
            { test:'NEOWISE W1/W2 light curve', result:'σ_var = 0.013 mag — photometrically quiet, not a YSO', effect:'disconfirm' },
            { test:'galactic latitude / SFR assoc.', result:'b = +31.4° — far from any star-forming region', effect:'disconfirm' },
          ], 0.03, true),
          hyp('data_artifact', 0.16, [
            { test:'AllWISE cc_flags / ext_flg', result:'cc_flags=0000, ext_flg=0 — clean, point-like', effect:'disconfirm' },
            { test:'nearby bright source / confusion', result:'no source < 12″; confusion score 0.04', effect:'disconfirm' },
          ], 0.01, true),
          hyp('techno_ir_excess', 0.10, [
            { test:'all natural hypotheses', result:'disconfirmed / strongly disfavored', effect:'support' },
            { test:'excess significance', result:'W3 6.1σ, W4 7.4σ above photosphere fit', effect:'support' },
          ], 0.90, false),
        ],
      };
    }
    if (outcome === 'kill') {
      // candidate G — killed by background AGN blend + centroid drift
      return {
        promote: false,
        hypotheses: [
          hyp('warm_debris_disk', 0.30, [
            { test:'T_dust / L_IR÷L_* locus', result:'T_dust=212K — formally outside locus, inconclusive', effect:'neutral' },
          ], 0.10, false),
          hyp('agn_blend', 0.24, [
            { test:'VLASS crossmatch @ pos', result:'VLASS J-source at 3.1″, S=4.2 mJy — radio counterpart PRESENT', effect:'support' },
            { test:'WISE centroid shift W1→W4', result:'Δ = 2.7″ ± 0.4″ toward radio source — migrates in long bands', effect:'support' },
          ], 0.86, false),
          hyp('young_stellar', 0.16, [
            { test:'NEOWISE W1/W2 light curve', result:'σ_var = 0.04 mag — mild, inconclusive', effect:'neutral' },
          ], 0.08, false),
          hyp('data_artifact', 0.14, [
            { test:'AllWISE cc_flags', result:'cc_flags=00D0 (W3 diffraction halo flag set)', effect:'support' },
          ], 0.20, false),
          hyp('techno_ir_excess', 0.16, [
            { test:'centroid migrates W1→W4', result:'excess co-located with background AGN, not the M-dwarf — DISCONFIRMED', effect:'disconfirm' },
          ], 0.02, true),
        ],
      };
    }
    // vetting / open — partway through
    return {
      promote: null,
      hypotheses: [
        hyp('warm_debris_disk', 0.34, [], 0.34, false),
        hyp('agn_blend', 0.22, [{ test:'VLASS / NVSS crossmatch', result:'pending — queued', effect:'neutral' }], 0.22, false),
        hyp('young_stellar', 0.18, [], 0.18, false),
        hyp('data_artifact', 0.16, [{ test:'AllWISE cc_flags / ext_flg', result:'cc_flags=0000, ext_flg=0 — clean', effect:'disconfirm' }], 0.05, true),
        hyp('techno_ir_excess', 0.10, [], 0.21, false),
      ],
    };
  }

  // ---- candidate factory ----------------------------------------------
  function cand(o) {
    const channels = o.channels;
    return {
      id: o.id, hepRef: o.hepRef || null,
      gaiaId: o.gaiaId, ra: o.ra, dec: o.dec, constellation: o.constellation,
      distance_pc: o.distance_pc, teff: o.teff, bp_rp: o.bp_rp, gmag: o.gmag, pm: o.pm,
      status: o.status, channels, nChannels: channels.length,
      jointFAP: o.jointFAP, anomScore: o.anomScore, tick: o.tick,
      surveys: o.surveys, sed: makeSED(o.teff, o.excess), excessBands: o.excessBands,
      ach: o.ach, car: o.car || null, note: o.note,
    };
  }

  const CANDIDATES = [
    cand({ id:'CL-2016-0473', hepRef:'A', gaiaId:'Gaia DR3 2050233812524482560', ra:288.42, dec:38.71, constellation:'Lyra',
      distance_pc:138, teff:3320, bp_rp:2.74, gmag:14.12, pm:121, status:'promoted', channels:['ir_excess'],
      jointFAP:3.1e-6, anomScore:7.4, tick:41822, surveys:['gaia_dr3','2mass','allwise'],
      excess:{ W3:0.55, W4:1.15 }, excessBands:['W3','W4'], ach:irAch('promote'),
      car:{ ref:'CAR-A1B2C3', generatedAt:'2016-118 / tick 41822',
        recommendedFollowup:['JWST MIRI 10–25µm spectroscopy to characterize excess SED','High-res VLA imaging at position to rule out faint blend below RACS depth','Optical spectroscopy to confirm M-dwarf type & check for accretion lines'],
        reproducibility:['gea.esac.esa.int/tap-server — ADQL: SELECT … WHERE parallax > 3.3 AND CONTAINS(POINT(ra,dec), CIRCLE(288.42,38.71,0.002))=1','irsa.ipac.caltech.edu/TAP — allwise_p3as_psd @ 288.42,+38.71 r=3″','irsa.ipac.caltech.edu/TAP — fp_psc (2MASS) @ 288.42,+38.71 r=3″'] } }),

    cand({ id:'CL-2016-0512', hepRef:'B', gaiaId:'Gaia DR3 4595142003948213760', ra:251.07, dec:14.82, constellation:'Hercules',
      distance_pc:96, teff:3180, bp_rp:2.91, gmag:13.44, pm:204, status:'promoted', channels:['ir_excess'],
      jointFAP:8.4e-6, anomScore:6.9, tick:41822, surveys:['gaia_dr3','2mass','allwise'],
      excess:{ W3:0.42, W4:0.95 }, excessBands:['W3','W4'], ach:irAch('promote'),
      car:{ ref:'CAR-D4E5F6', generatedAt:'2016-118 / tick 41822',
        recommendedFollowup:['JWST MIRI spectroscopy','SED follow-up with Herschel archival / ALMA continuum','Confirm parallax-based distance < 300 pc'],
        reproducibility:['gea.esac.esa.int/tap-server @ 251.07,+14.82','irsa allwise_p3as_psd @ 251.07,+14.82 r=3″','irsa fp_psc @ 251.07,+14.82 r=3″'] } }),

    cand({ id:'CL-2016-0588', hepRef:'C', gaiaId:'Gaia DR3 1823773960286408576', ra:312.55, dec:21.16, constellation:'Vulpecula',
      distance_pc:201, teff:3460, bp_rp:2.58, gmag:14.88, pm:67, status:'vetting', channels:['ir_excess'],
      jointFAP:2.2e-5, anomScore:6.1, tick:42010, surveys:['gaia_dr3','2mass','allwise'],
      excess:{ W3:0.36, W4:0.72 }, excessBands:['W3','W4'], ach:irAch('vetting') }),

    cand({ id:'CL-2016-0601', hepRef:'D', gaiaId:'Gaia DR3 4282115844458192384', ra:279.31, dec:6.44, constellation:'Aquila',
      distance_pc:154, teff:3290, bp_rp:2.81, gmag:14.31, pm:98, status:'vetting', channels:['ir_excess'],
      jointFAP:1.7e-5, anomScore:6.4, tick:42010, surveys:['gaia_dr3','2mass','allwise'],
      excess:{ W3:0.40, W4:0.83 }, excessBands:['W3','W4'], ach:irAch('vetting') }),

    cand({ id:'CL-2016-0644', hepRef:'E', gaiaId:'Gaia DR3 4475723132563261440', ra:264.18, dec:12.07, constellation:'Ophiuchus',
      distance_pc:73, teff:3060, bp_rp:3.12, gmag:12.95, pm:288, status:'promoted', channels:['ir_excess'],
      jointFAP:5.0e-6, anomScore:7.1, tick:41980, surveys:['gaia_dr3','2mass','allwise'],
      excess:{ W2:0.08, W3:0.49, W4:1.02 }, excessBands:['W3','W4'], ach:irAch('promote'),
      car:{ ref:'CAR-7A8B9C', generatedAt:'2016-116 / tick 41980',
        recommendedFollowup:['JWST MIRI spectroscopy — highest-priority of the set (nearest, brightest)','Adaptive-optics imaging to exclude sub-arcsec companion','NEOWISE epoch-by-epoch re-reduction'],
        reproducibility:['gea.esac.esa.int/tap-server @ 264.18,+12.07','irsa allwise_p3as_psd @ 264.18,+12.07 r=3″','irsa fp_psc @ 264.18,+12.07 r=3″'] } }),

    cand({ id:'CL-2016-0659', hepRef:'F', gaiaId:'Gaia DR3 1322827215486391552', ra:232.94, dec:33.28, constellation:'Corona Borealis',
      distance_pc:182, teff:3400, bp_rp:2.64, gmag:14.66, pm:54, status:'open', channels:['ir_excess'],
      jointFAP:4.1e-5, anomScore:5.6, tick:42044, surveys:['gaia_dr3','2mass','allwise'],
      excess:{ W3:0.31, W4:0.61 }, excessBands:['W3','W4'], ach:irAch('vetting') }),

    cand({ id:'CL-2016-0677', hepRef:'G', gaiaId:'Gaia DR3 4316240079211286528', ra:298.10, dec:9.53, constellation:'Aquila',
      distance_pc:225, teff:3510, bp_rp:2.49, gmag:15.02, pm:41, status:'killed', channels:['ir_excess'],
      jointFAP:6.6e-5, anomScore:5.2, tick:41760, surveys:['gaia_dr3','2mass','allwise'],
      excess:{ W3:0.46, W4:0.70 }, excessBands:['W3','W4'], ach:irAch('kill'),
      note:'Killed: WISE centroid migrates 2.7″ toward a VLASS radio source across W1→W4. Excess belongs to a background AGN, not the M-dwarf. Textbook §6 agn_blend disconfirmer.' }),

    // ---- multi-channel candidates (v0.2 preview) ----
    cand({ id:'CL-2025-θ021', gaiaId:'Gaia DR3 2603925217961438976', ra:341.62, dec:-8.74, constellation:'Aquarius',
      distance_pc:44, teff:3240, bp_rp:2.86, gmag:11.83, pm:332, status:'vetting', channels:['ir_excess','transit_shape','radio_drift'],
      jointFAP:2.3e-10, anomScore:8.8, tick:42071, surveys:['gaia_dr3','2mass','allwise','tess','bldr'],
      excess:{ W3:0.62, W4:1.28 }, excessBands:['W3','W4'],
      ach:{ promote:null, hypotheses:[
        hyp('warm_debris_disk',0.30,[{test:'T_dust locus',result:'T_dust=132K — outside locus',effect:'disconfirm'}],0.04,true),
        hyp('agn_blend',0.18,[{test:'VLASS / centroid',result:'no radio source; Δcentroid=0.1″',effect:'disconfirm'}],0.01,true),
        hyp('rfi_terrestrial',0.20,[{test:'ON/OFF cadence test (BL)',result:'narrowband 8.42GHz signal present in ON, absent in 3 OFF pointings',effect:'disconfirm'}],0.03,true),
        hyp('stellar_pulsation',0.14,[{test:'TESS transit-shape fit',result:'aperiodic, non-U-shaped dips — not pulsation, not planet',effect:'neutral'}],0.10,false),
        hyp('techno_multichannel',0.18,[{test:'3 physics-independent channels co-located <0.4″',result:'IR excess + aperiodic transits + drifting narrowband all @ same position',effect:'support'}],0.82,false),
      ] },
      note:'Three physics-independent channels agree on one sky position to <0.4″. This is the configuration v0.1 is built to recognize but cannot yet promote (nch>=3 path goes live in v0.2).' }),

    cand({ id:'CL-2025-ψ006', gaiaId:'Gaia DR3 5853498713190525696', ra:217.39, dec:-62.68, constellation:'Circinus',
      distance_pc:88, teff:3370, bp_rp:2.69, gmag:13.07, pm:176, status:'open', channels:['ir_excess','astrometric'],
      jointFAP:9.1e-8, anomScore:7.6, tick:42071, surveys:['gaia_dr3','2mass','allwise'],
      excess:{ W3:0.38, W4:0.78 }, excessBands:['W3','W4'],
      ach:{ promote:null, hypotheses:[
        hyp('warm_debris_disk',0.32,[],0.32,false),
        hyp('astrometric_binary',0.28,[{test:'Gaia RUWE / accel. solution',result:'RUWE=2.4, significant astrometric acceleration — unmodeled companion',effect:'support'}],0.55,false),
        hyp('agn_blend',0.18,[{test:'radio crossmatch',result:'pending',effect:'neutral'}],0.18,false),
        hyp('techno_multichannel',0.12,[],0.16,false),
      ] }, note:'IR excess + anomalous Gaia astrometry (RUWE 2.4). Two channels; debris-disk vs. unseen companion not yet resolved.' }),
  ];

  // ---- dashboard: cycle / tiers / ingestion / funnel / activity --------
  const CYCLE = {
    tick: 42071, channelName: 'chorus-alpha',
    phases: ['INGEST','CROSSMATCH','SCORE','PROMOTE','ADJUDICATE','REPORT','RETROSPECT'],
    activePhase: 4, // ADJUDICATE
    uptimeDays: 312, commonEpoch: 'J2016.0',
  };

  const TIERS = [
    { id:0, name:'SPATIAL CROSSMATCH', sub:'HEALPix Nside=1024 · astropy sidecar', status:'nominal', metric:'2,310 px/tick', detail:'epoch→J2016.0 · k-d match' },
    { id:1, name:'ANOMALY SCORERS', sub:'IrExcessScorer (1 of 4 channels live)', status:'nominal', metric:'18.4k det/tick', detail:'SED fit · reject filters' },
    { id:2, name:'GRAPH — MEMGRAPH', sub:'Bolt 7687 · APOC-free dual-write', status:'nominal', metric:'9 candidates', detail:'COINCIDES_WITH · ACH subgraph' },
    { id:3, name:'MXF AGENT LAYER', sub:'Sonnet adjudicator · ephemeral', status:'busy', metric:'2 vetting now', detail:'ACH disconfirming tests' },
  ];

  const SIDECAR = { status:'nominal', svc:'astropy + healpy + scipy', port:8771, p95:'214ms' };
  const STORES = [
    { name:'MongoDB', sub:'source of truth', status:'nominal', metric:'1.42M detections' },
    { name:'Meilisearch', sub:'candidate index', status:'nominal', metric:'9 docs · 12ms' },
    { name:'Slack', sub:'#chorus-alpha', status:'nominal', metric:'5 CARs posted' },
  ];

  const INGEST = [
    { survey:'gaia_dr3', label:'Gaia DR3', endpoint:'gea.esac.esa.int/tap', channel:'astrometric', pulled:'1.04M', pixels:1284, epoch:'2016.0', spark:[4,6,5,8,7,9,6,8,7,9,8,10] },
    { survey:'allwise', label:'AllWISE',  endpoint:'irsa.ipac TAP', channel:'ir_excess', pulled:'986k', pixels:1284, epoch:'2010.5', spark:[5,5,7,6,8,6,7,9,7,8,9,8] },
    { survey:'2mass', label:'2MASS PSC',  endpoint:'irsa.ipac TAP', channel:'(input)', pulled:'742k', pixels:1284, epoch:'1999.3', spark:[3,4,4,5,4,6,5,5,6,5,6,7] },
    { survey:'tess', label:'TESS', endpoint:'MAST', channel:'transit_shape', pulled:'—', pixels:0, epoch:'deferred', spark:[0,0,0,0,0,0,0,0,0,0,0,0], deferred:true },
    { survey:'bldr', label:'BL Open Data', endpoint:'bl-opendata', channel:'radio_drift', pulled:'—', pixels:0, epoch:'deferred', spark:[0,0,0,0,0,0,0,0,0,0,0,0], deferred:true },
  ];

  const FUNNEL = [
    { label:'Catalog sources scanned', value:'4.97M', n:4970000, tier:'TIER 0' },
    { label:'Position clusters (≥1 survey)', value:'1.42M', n:1420000, tier:'TIER 0' },
    { label:'Passed anomaly cut (Tier 1)', value:'18,402', n:18402, tier:'TIER 1' },
    { label:'Promoted to Candidate', value:'9', n:9, tier:'TIER 2' },
    { label:'Survived ACH → CAR', value:'5', n:5, tier:'TIER 3' },
  ];

  const ACTIVITY = [
    { t:'42071.4', lvl:'agent', msg:'ACH adjudicator spun for CL-2025-θ021 · 5 hypotheses enumerated' },
    { t:'42071.3', lvl:'tool',  msg:'sidecar: ON/OFF cadence test → narrowband 8.42GHz present in ON only' },
    { t:'42071.1', lvl:'ok',    msg:'crossmatch px 392841 (+8 neighbors) → 47 clusters, 3 multi-survey' },
    { t:'42070.9', lvl:'ok',    msg:'IrExcessScorer: 214 detections scored, 2 passed cut' },
    { t:'42070.6', lvl:'warn',  msg:'CL-2016-0677 (G) reclassified killed · centroid drift 2.7″ → AGN blend' },
    { t:'42070.2', lvl:'ok',    msg:'dual-write Memgraph: +2 Candidate, +6 SUPPORTED_BY' },
    { t:'42069.8', lvl:'agent', msg:'CAR-7A8B9C generated for CL-2016-0644 (E) → posted #chorus-alpha' },
    { t:'42069.5', lvl:'tool',  msg:'VLASS crossmatch CL-2016-0644: no source < 8″, RACS 3σ<0.9mJy' },
    { t:'42069.1', lvl:'ok',    msg:'epoch propagation: 742k 2MASS pos J1999.3→J2016.0 (astropy)' },
  ];

  // validation gate (§11)
  const GATE = { target:7, recovered:6, killed:1, label:'Hephaistos seven · ir_excess', note:'6 of 7 recovered as promoted/vetting; candidate G correctly killed (background-AGN blend). Divergence explained → gate PASS.' };

  window.CHORUS = { CHANNELS, CANDIDATES, CYCLE, TIERS, SIDECAR, STORES, INGEST, FUNNEL, ACTIVITY, GATE,
    channelColor: (k) => `var(${CHANNELS[k] ? CHANNELS[k].varName : '--ink-dim'})`,
    fmtFAP: (v) => { if (v == null) return '—'; const e = Math.floor(Math.log10(v)); const m = (v / Math.pow(10, e)).toFixed(1); return `${m}e${e}`; },
    candidateById: (id) => CANDIDATES.find(c => c.id === id),
  };
})();
