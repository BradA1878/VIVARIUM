/* ============================================================
   CHORUS shared components
   exported to window for cross-file use (Babel scope isolation)
   ============================================================ */
const { useState, useEffect, useRef, useMemo } = React;

const C = () => window.CHORUS;

/* ---- corner-bracket panel ---- */
function Panel({ children, className = '', flat = false, brackets = true, ...rest }) {
  return (
    <div className={`panel ${flat ? 'panel--flat' : ''} ${brackets ? 'bracket' : ''} ${className}`} {...rest}>
      {brackets && <span className="bracket-b" />}
      {children}
    </div>
  );
}

/* ---- section header strip ---- */
function Strip({ label, right, accent }) {
  return (
    <div className="scan" style={{ display:'flex', alignItems:'center', justifyContent:'space-between',
      padding:'8px 12px', borderBottom:'1px solid var(--line-soft)' }}>
      <div style={{ display:'flex', alignItems:'center', gap:8 }}>
        {accent && <span className="dot" style={{ background: accent }} />}
        <span className="eyebrow">{label}</span>
      </div>
      {right && <div style={{ display:'flex', alignItems:'center', gap:10 }}>{right}</div>}
    </div>
  );
}

/* ---- channel glyph: short code in a colored cell ---- */
function ChannelGlyph({ ch, size = 22, dim = false }) {
  const meta = C().CHANNELS[ch];
  if (!meta) return null;
  const col = `var(${meta.varName})`;
  return (
    <span title={`${meta.label} · ${meta.survey} · ${meta.wl}`} style={{
      display:'inline-flex', alignItems:'center', justifyContent:'center',
      width:size, height:size, fontSize:10, fontWeight:600, letterSpacing:'0.04em',
      color: dim ? 'var(--ink-faint)' : col, fontFamily:'var(--mono)',
      border:`1px solid ${dim ? 'var(--line)' : `color-mix(in oklch, ${col}, transparent 55%)`}`,
      background: dim ? 'transparent' : `color-mix(in oklch, ${col}, var(--void) 86%)`,
      borderRadius:2, flex:'none',
    }}>{meta.short}</span>
  );
}

function ChannelRow({ channels, size = 22, max = 4 }) {
  const all = ['ir_excess','transit_shape','radio_drift','astrometric'];
  return (
    <div style={{ display:'flex', gap:4 }}>
      {all.slice(0, max).map(ch => (
        <ChannelGlyph key={ch} ch={ch} size={size} dim={!channels.includes(ch)} />
      ))}
    </div>
  );
}

/* ---- status badge ---- */
const STATUS_META = {
  promoted: { cls:'is-promoted', label:'PROMOTED', col:'var(--signal)' },
  vetting:  { cls:'is-vetting',  label:'VETTING',  col:'var(--amber)' },
  open:     { cls:'is-open',     label:'OPEN',     col:'var(--ink-faint)' },
  killed:   { cls:'is-killed',   label:'KILLED',   col:'var(--red)' },
};
function StatusBadge({ status, pulse = false }) {
  const m = STATUS_META[status] || STATUS_META.open;
  return (
    <span className={`chip ${m.cls}`}>
      <span className={`dot ${pulse && status==='vetting' ? 'live' : ''}`} style={{ background:m.col }} />
      {m.label}
    </span>
  );
}

/* ============================================================
   CONVERGENCE TARGET — the hero visual.
   N physics-independent channels drawn as colored arcs at distinct
   radii, all locked onto one sky position (center crosshair).
   ============================================================ */
function ConvergenceTarget({ channels, status, size = 120, animate = true }) {
  const cx = size/2, cy = size/2;
  const all = ['ir_excess','transit_shape','radio_drift','astrometric'].filter(c => channels.includes(c));
  const maxR = size*0.40;
  const ringGap = maxR / (all.length + 0.6);
  const statusCol = (STATUS_META[status]||STATUS_META.open).col;

  // arc path (an arc spanning `span` deg starting at `start`)
  function arc(r, start, span) {
    const a0 = (start) * Math.PI/180, a1 = (start+span) * Math.PI/180;
    const x0 = cx + r*Math.cos(a0), y0 = cy + r*Math.sin(a0);
    const x1 = cx + r*Math.cos(a1), y1 = cy + r*Math.sin(a1);
    const large = span > 180 ? 1 : 0;
    return `M ${x0} ${y0} A ${r} ${r} 0 ${large} 1 ${x1} ${y1}`;
  }

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ display:'block', overflow:'visible' }}>
      {/* faint graticule */}
      {[0.25,0.55,0.85].map((f,i)=>(
        <circle key={i} cx={cx} cy={cy} r={maxR*f+ringGap*0.3} fill="none" stroke="var(--line-soft)" strokeWidth="0.75" />
      ))}
      {/* crosshair */}
      <line x1={cx-size*0.46} y1={cy} x2={cx+size*0.46} y2={cy} stroke="var(--line)" strokeWidth="0.75" />
      <line x1={cx} y1={cy-size*0.46} x2={cx} y2={cy+size*0.46} stroke="var(--line)" strokeWidth="0.75" />

      {/* channel arcs */}
      {all.map((ch, i) => {
        const r = ringGap*(i+1.2);
        const col = `var(${C().CHANNELS[ch].varName})`;
        const start = -90 + i*34;
        return (
          <g key={ch} className={animate ? 'reveal' : ''} style={{ animationDelay:`${i*120}ms` }}>
            <path d={arc(r, start, 250)} fill="none" stroke={col} strokeWidth="2.2" strokeLinecap="round"
              style={{ filter:`drop-shadow(0 0 4px color-mix(in oklch, ${col}, transparent 40%))` }} />
            {/* inward tick toward center */}
            <line x1={cx + (r+4)*Math.cos((start)*Math.PI/180)} y1={cy + (r+4)*Math.sin((start)*Math.PI/180)}
                  x2={cx + (r-5)*Math.cos((start)*Math.PI/180)} y2={cy + (r-5)*Math.sin((start)*Math.PI/180)}
                  stroke={col} strokeWidth="1.6" />
          </g>
        );
      })}

      {/* center lock */}
      <circle cx={cx} cy={cy} r={4.5} fill="var(--void)" stroke={statusCol} strokeWidth="1.5" />
      <circle cx={cx} cy={cy} r={1.6} fill={statusCol} className={animate && status==='vetting' ? 'live' : ''} />
    </svg>
  );
}

/* ---- sparkline ---- */
function Sparkline({ data, color = 'var(--signal-dim)', w = 84, h = 22 }) {
  if (!data || !data.length) return null;
  const max = Math.max(...data, 1), min = Math.min(...data);
  const pts = data.map((v,i)=>{
    const x = (i/(data.length-1))*w;
    const y = h - ((v-min)/((max-min)||1))*(h-3) - 1.5;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
  return (
    <svg width={w} height={h} style={{ display:'block' }}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.4" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

/* ============================================================
   SED PLOT — photosphere fit + MIR excess (the ir_excess smoking gun)
   ============================================================ */
function SEDPlot({ sed, w = 540, h = 280 }) {
  const pad = { l:42, r:16, t:16, b:38 };
  const iw = w - pad.l - pad.r, ih = h - pad.t - pad.b;
  const xs = sed.map(b=>Math.log10(b.wl));
  const xMin = Math.log10(0.42), xMax = Math.log10(28);
  const ys = sed.flatMap(b=>[b.logModel, b.logObs]);
  const yMin = Math.min(...ys) - 0.15, yMax = Math.max(...ys) + 0.1;
  const X = (lw)=> pad.l + ((lw - xMin)/(xMax-xMin))*iw;
  const Y = (lf)=> pad.t + (1-(lf - yMin)/(yMax-yMin))*ih;

  const modelPath = sed.map((b,i)=>`${i?'L':'M'} ${X(Math.log10(b.wl)).toFixed(1)} ${Y(b.logModel).toFixed(1)}`).join(' ');
  const xticks = [0.5,1,2,5,10,20];
  const yticks = []; for (let v=Math.ceil(yMin); v<=Math.floor(yMax); v++) yticks.push(v);

  const srcCol = { gaia:'var(--ch-astro)', '2mass':'var(--ink-dim)', wise:'var(--ch-ir)' };

  return (
    <svg width="100%" viewBox={`0 0 ${w} ${h}`} style={{ display:'block' }}>
      {/* grid */}
      {xticks.map(t=>(<line key={'x'+t} x1={X(Math.log10(t))} y1={pad.t} x2={X(Math.log10(t))} y2={pad.t+ih} stroke="var(--line-soft)" strokeWidth="0.6" />))}
      {yticks.map(t=>(<line key={'y'+t} x1={pad.l} y1={Y(t)} x2={pad.l+iw} y2={Y(t)} stroke="var(--line-soft)" strokeWidth="0.6" />))}

      {/* excess shading between model and obs for excess bands */}
      {sed.filter(b=>b.excess>0.04).map(b=>{
        const x = X(Math.log10(b.wl));
        return (
          <g key={'ex'+b.name}>
            <line x1={x} y1={Y(b.logModel)} x2={x} y2={Y(b.logObs)} stroke="var(--ch-ir)" strokeWidth="7"
              opacity="0.20" strokeLinecap="round" />
            <line x1={x} y1={Y(b.logModel)} x2={x} y2={Y(b.logObs)} stroke="var(--ch-ir)" strokeWidth="1" strokeDasharray="2 2" opacity="0.7" />
          </g>
        );
      })}

      {/* photosphere model */}
      <path d={modelPath} fill="none" stroke="var(--ink-faint)" strokeWidth="1.4" strokeDasharray="5 3" />

      {/* observed points + error bars */}
      {sed.map(b=>{
        const x = X(Math.log10(b.wl)), y = Y(b.logObs);
        const col = srcCol[b.src] || 'var(--ink-dim)';
        const isExcess = b.excess>0.04;
        return (
          <g key={b.name}>
            <line x1={x} y1={Y(b.logObs-b.err)} x2={x} y2={Y(b.logObs+b.err)} stroke={col} strokeWidth="1" opacity="0.8" />
            <circle cx={x} cy={y} r={isExcess?4:3} fill={isExcess?'var(--ch-ir)':col}
              stroke="var(--void)" strokeWidth="1" />
            <text x={x} y={pad.t+ih+13} textAnchor="middle" fontSize="8.5" fill="var(--ink-faint)" fontFamily="var(--mono)">{b.name}</text>
          </g>
        );
      })}

      {/* x ticks (wavelength) */}
      {xticks.map(t=>(<text key={'xt'+t} x={X(Math.log10(t))} y={pad.t+ih+26} textAnchor="middle" fontSize="8.5" fill="var(--ink-ghost)" fontFamily="var(--mono)">{t}</text>))}
      <text x={pad.l+iw/2} y={h-3} textAnchor="middle" fontSize="9" fill="var(--ink-faint)" fontFamily="var(--mono)" letterSpacing="0.1em">WAVELENGTH  λ / µm</text>
      <text x={11} y={pad.t+ih/2} textAnchor="middle" fontSize="9" fill="var(--ink-faint)" fontFamily="var(--mono)" letterSpacing="0.1em" transform={`rotate(-90 11 ${pad.t+ih/2})`}>log νFν (norm)</text>

      {/* axes */}
      <line x1={pad.l} y1={pad.t} x2={pad.l} y2={pad.t+ih} stroke="var(--line-bright)" strokeWidth="1" />
      <line x1={pad.l} y1={pad.t+ih} x2={pad.l+iw} y2={pad.t+ih} stroke="var(--line-bright)" strokeWidth="1" />
    </svg>
  );
}

/* ---- key/value stat ---- */
function Stat({ label, value, unit, color, big }) {
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:3 }}>
      <span className="eyebrow">{label}</span>
      <span className="tnum" style={{ fontSize: big?22:15, color: color||'var(--ink)', fontWeight:500, lineHeight:1 }}>
        {value}{unit && <span style={{ fontSize:11, color:'var(--ink-faint)', marginLeft:3 }}>{unit}</span>}
      </span>
    </div>
  );
}

function fmtCoord(ra, dec) {
  const d = (v)=> (v>=0?'+':'−') + Math.abs(v).toFixed(2);
  return `α ${ra.toFixed(2)}°  δ ${d(dec)}°`;
}

Object.assign(window, {
  Panel, Strip, ChannelGlyph, ChannelRow, StatusBadge, STATUS_META,
  ConvergenceTarget, Sparkline, SEDPlot, Stat, fmtCoord,
});
