/* ============================================================
   VIEW · MISSION CONTROL (dashboard)
   ============================================================ */
const { useState: useStateD, useEffect: useEffectD } = React;
const CD = () => window.CHORUS;

function PhasePipeline() {
  const { phases, activePhase } = CD().CYCLE;
  return (
    <div style={{ display:'flex', alignItems:'stretch', gap:0, overflowX:'auto' }}>
      {phases.map((p,i)=>{
        const active = i===activePhase, done = i<activePhase;
        return (
          <div key={p} style={{ display:'flex', alignItems:'center', flex:'1 1 0', minWidth:96 }}>
            <div style={{ flex:1, display:'flex', flexDirection:'column', gap:6, alignItems:'center', padding:'2px 4px' }}>
              <div style={{ width:'100%', height:3, background: active?'var(--signal)':done?'var(--signal-dim)':'var(--line)',
                boxShadow: active?'0 0 8px var(--signal)':'none' }} className={active?'live':''} />
              <span style={{ fontSize:9, letterSpacing:'0.12em', color: active?'var(--signal)':done?'var(--ink-dim)':'var(--ink-ghost)' }}>{p}</span>
            </div>
            {i<phases.length-1 && <span style={{ color:'var(--ink-ghost)', fontSize:10 }}>›</span>}
          </div>
        );
      })}
    </div>
  );
}

function TierCard({ tier }) {
  const col = tier.status==='nominal'?'var(--signal)':tier.status==='busy'?'var(--amber)':'var(--red)';
  return (
    <div style={{ display:'flex', gap:11, padding:'11px 13px', borderBottom:'1px solid var(--line-soft)', alignItems:'flex-start' }}>
      <div style={{ fontFamily:'var(--mono)', fontSize:11, color:'var(--ink-ghost)', marginTop:1, width:14 }}>{tier.id}</div>
      <div style={{ flex:1, minWidth:0 }}>
        <div style={{ display:'flex', alignItems:'center', gap:8 }}>
          <span className="dot" style={{ background:col }} />
          <span style={{ fontSize:11.5, letterSpacing:'0.06em', color:'var(--ink)' }}>{tier.name}</span>
        </div>
        <div style={{ fontSize:10, color:'var(--ink-faint)', marginTop:3 }}>{tier.sub}</div>
        <div style={{ fontSize:10, color:'var(--ink-ghost)', marginTop:2 }}>{tier.detail}</div>
      </div>
      <div style={{ textAlign:'right' }}>
        <div className="tnum" style={{ fontSize:11.5, color:col }}>{tier.metric}</div>
        <div style={{ fontSize:9, letterSpacing:'0.1em', color:'var(--ink-ghost)', marginTop:3 }}>{tier.status.toUpperCase()}</div>
      </div>
    </div>
  );
}

function FunnelViz() {
  const f = CD().FUNNEL;
  const logs = f.map(s=>Math.log10(s.n));
  const max = logs[0], min = logs[logs.length-1];
  return (
    <div style={{ padding:'14px 16px', display:'flex', flexDirection:'column', gap:9 }}>
      {f.map((s,i)=>{
        const w = 24 + ((logs[i]-min)/(max-min))*76; // %
        const t = i/(f.length-1);
        const col = `color-mix(in oklch, var(--signal) ${Math.round(t*100)}%, var(--ink-faint))`;
        return (
          <div key={s.label} style={{ display:'flex', alignItems:'center', gap:12 }}>
            <div style={{ width:62, textAlign:'right', flex:'none' }}>
              <div style={{ fontSize:8.5, letterSpacing:'0.1em', color:'var(--ink-ghost)' }}>{s.tier}</div>
            </div>
            <div style={{ flex:1, position:'relative', height:30 }}>
              <div style={{ position:'absolute', inset:0, width:`${w}%`,
                background:`linear-gradient(90deg, color-mix(in oklch, ${col}, var(--void) 78%), color-mix(in oklch, ${col}, var(--void) 90%))`,
                border:`1px solid color-mix(in oklch, ${col}, transparent 55%)`, borderRadius:2,
                display:'flex', alignItems:'center', justifyContent:'space-between', padding:'0 10px' }}>
                <span style={{ fontSize:10.5, color:'var(--ink-dim)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{s.label}</span>
                <span className="tnum" style={{ fontSize:13, fontWeight:600, color:col, flex:'none', marginLeft:8 }}>{s.value}</span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function GatePanel() {
  const g = CD().GATE;
  return (
    <div style={{ padding:'13px 16px' }}>
      <div style={{ display:'flex', alignItems:'center', gap:14, marginBottom:11 }}>
        <div style={{ display:'flex', alignItems:'baseline', gap:5 }}>
          <span className="tnum" style={{ fontSize:30, fontWeight:600, color:'var(--signal)', lineHeight:1 }}>{g.recovered}</span>
          <span className="tnum" style={{ fontSize:15, color:'var(--ink-faint)' }}>/ {g.target}</span>
        </div>
        <div style={{ flex:1 }}>
          <div style={{ display:'flex', gap:3 }}>
            {Array.from({length:g.target}).map((_,i)=>(
              <div key={i} style={{ flex:1, height:8, borderRadius:1,
                background: i<g.recovered?'var(--signal)':i<g.recovered+g.killed?'var(--red)':'var(--line)' }} />
            ))}
          </div>
          <div style={{ fontSize:9.5, color:'var(--ink-ghost)', marginTop:5, letterSpacing:'0.06em' }}>{g.label}</div>
        </div>
        <span className="chip is-promoted">GATE · PASS</span>
      </div>
      <p className="sans" style={{ fontSize:11.5, color:'var(--ink-dim)', lineHeight:1.5, textWrap:'pretty' }}>{g.note}</p>
    </div>
  );
}

function IngestPanel() {
  const ing = CD().INGEST;
  return (
    <div>
      {ing.map(s=>(
        <div key={s.survey} style={{ display:'flex', alignItems:'center', gap:10, padding:'9px 13px',
          borderBottom:'1px solid var(--line-soft)', opacity: s.deferred?0.45:1 }}>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ display:'flex', alignItems:'center', gap:7 }}>
              <span style={{ fontSize:11.5, color:'var(--ink)' }}>{s.label}</span>
              {s.deferred && <span className="chip" style={{ fontSize:8.5, padding:'1px 5px' }}>DEFERRED</span>}
            </div>
            <div style={{ fontSize:9.5, color:'var(--ink-ghost)', marginTop:2 }}>{s.endpoint} · ep {s.epoch}</div>
          </div>
          <Sparkline data={s.spark} color={s.deferred?'var(--line-bright)':'var(--signal-dim)'} w={64} h={20} />
          <div style={{ textAlign:'right', width:62, flex:'none' }}>
            <div className="tnum" style={{ fontSize:11.5, color: s.deferred?'var(--ink-ghost)':'var(--ink-dim)' }}>{s.pulled}</div>
            <div style={{ fontSize:8.5, color:'var(--ink-ghost)' }}>sources</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function ActivityLog() {
  const a = CD().ACTIVITY;
  const lvlCol = { ok:'var(--signal-dim)', warn:'var(--amber)', agent:'var(--ch-radio)', tool:'var(--ch-transit)', err:'var(--red)' };
  return (
    <div className="scroll" style={{ maxHeight:'100%', padding:'4px 0' }}>
      {a.map((e,i)=>(
        <div key={i} style={{ display:'flex', gap:9, padding:'5px 13px', fontSize:11, lineHeight:1.4 }}>
          <span className="tnum" style={{ color:'var(--ink-ghost)', flex:'none' }}>{e.t}</span>
          <span style={{ color:lvlCol[e.lvl], flex:'none', width:42, fontSize:9, letterSpacing:'0.08em', paddingTop:1 }}>{e.lvl.toUpperCase()}</span>
          <span style={{ color:'var(--ink-dim)', minWidth:0 }}>{e.msg}</span>
        </div>
      ))}
      <div style={{ padding:'4px 13px', color:'var(--ink-ghost)', fontSize:11 }}><span className="caret">listening</span></div>
    </div>
  );
}

function DashboardView({ go }) {
  const cy = CD().CYCLE, sc = CD().SIDECAR, stores = CD().STORES;
  return (
    <div className="scroll" style={{ height:'100%', padding:18 }}>
      {/* cycle header */}
      <Panel style={{ marginBottom:14 }}>
        <Strip label="CYCLE RUNNER · chorus-alpha" accent="var(--signal)" right={
          <>
            <span className="chip"><span className="dot live" style={{ background:'var(--signal)' }} />TICK {cy.tick.toLocaleString()}</span>
            <span className="chip">UPTIME {cy.uptimeDays}d</span>
            <span className="chip">EPOCH {cy.commonEpoch}</span>
          </>
        } />
        <div style={{ padding:'16px 18px 18px' }}><PhasePipeline /></div>
      </Panel>

      {/* main grid */}
      <div style={{ display:'grid', gridTemplateColumns:'minmax(280px, 1fr) minmax(380px, 1.5fr) minmax(300px, 1.1fr)', gap:14, alignItems:'start' }}>
        {/* col 1 — tiers + infra */}
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          <Panel>
            <Strip label="TIER HEALTH" right={<span className="eyebrow">4 TIERS</span>} />
            {CD().TIERS.map(t=><TierCard key={t.id} tier={t} />)}
          </Panel>
          <Panel>
            <Strip label="INFRASTRUCTURE" />
            <div style={{ display:'flex', alignItems:'center', gap:10, padding:'10px 13px', borderBottom:'1px solid var(--line-soft)' }}>
              <span className="dot" style={{ background:'var(--signal)' }} />
              <div style={{ flex:1 }}>
                <div style={{ fontSize:11.5 }}>Python numerics sidecar</div>
                <div style={{ fontSize:9.5, color:'var(--ink-ghost)' }}>{sc.svc} · :{sc.port}</div>
              </div>
              <span className="tnum" style={{ fontSize:11, color:'var(--ink-dim)' }}>p95 {sc.p95}</span>
            </div>
            {stores.map(s=>(
              <div key={s.name} style={{ display:'flex', alignItems:'center', gap:10, padding:'10px 13px', borderBottom:'1px solid var(--line-soft)' }}>
                <span className="dot" style={{ background:'var(--signal)' }} />
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:11.5 }}>{s.name}</div>
                  <div style={{ fontSize:9.5, color:'var(--ink-ghost)' }}>{s.sub}</div>
                </div>
                <span className="tnum" style={{ fontSize:11, color:'var(--ink-dim)' }}>{s.metric}</span>
              </div>
            ))}
          </Panel>
        </div>

        {/* col 2 — funnel + gate */}
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          <Panel>
            <Strip label="CANDIDATE FUNNEL · this scan" accent="var(--signal)" right={<span className="lnk" onClick={()=>go('queue')}>view queue →</span>} />
            <FunnelViz />
          </Panel>
          <Panel>
            <Strip label="VALIDATION GATE · §11" accent="var(--signal)" />
            <GatePanel />
          </Panel>
          <Panel>
            <Strip label="INGESTION · per-survey delta" right={<span className="eyebrow">{CD().INGEST.length} ADAPTERS</span>} />
            <IngestPanel />
          </Panel>
        </div>

        {/* col 3 — activity */}
        <Panel style={{ height:'100%', minHeight:520, display:'flex', flexDirection:'column' }}>
          <Strip label="EVENT STREAM" accent="var(--ch-transit)" right={<span className="dot live" style={{ background:'var(--ch-transit)' }} />} />
          <div style={{ flex:1, minHeight:0 }}><ActivityLog /></div>
        </Panel>
      </div>
    </div>
  );
}

Object.assign(window, { DashboardView });
